"""v1.001.0 install layout, install.conf, version, systemd unit and transaction helpers.

Standard library only: imported by the production installer, executed by
patch.sh / ROLLBACK_NOW.sh through the bundled runtime
(``python3 -I -B layout.py <command>``), and imported by make_patch.py.

Layout (each overridable through PROJECTAPP_APP / PROJECTAPP_DATA /
PROJECTAPP_RUNTIME or installer arguments; an existing install.conf wins and
is never moved automatically):
    /opt/projectapp/app      releases/<version>-<build12>/ + current -> releases/...
    /opt/projectapp/data     install.conf, config.json, db/ (0700), attachments/,
                             backups/, <kind>_backup_<ts>/, *_audit.log,
                             install_txn.json (only while a transaction is open)
    /opt/projectapp/runtime  bundled Python (the payload's runtime/ subtree)

Transactions (full install/upgrade and patch share one format): before the
first change the caller creates DATA_DIR/<kind>_backup_<ts>_<pid>/ (root
0700) holding txn.json + copies of install.conf, the unit and
INSTALLATION.json, then publishes DATA_DIR/install_txn.json (atomic write,
fsync of file and directory). The journal stays until the run either commits
(success audit written first) or is fully rolled back. While it exists the
systemd unit's ExecStartPre refuses to start the service; a rollback starts
the previous version only after its terminal state is on disk and the
journal is closed. The loopback check-port server needs a /run token bound
to the live installer process. Rollback (automatic, on rerun, through the
fixed ROLLBACK_NOW.sh or INSTALL.sh --recover) is one function: rollback().
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import http.client
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import socket
import sqlite3
import secrets
import stat
import subprocess
import sys
import time
# A FULL-package rollback swaps runtime/ back while THIS interpreter (the new
# runtime, now renamed runtime.retained-*) keeps running. Anything imported
# lazily after that swap is looked up in a directory that no longer has it:
# the 221 v1.001.0 -> 2.000 upgrade/rollback test died in the post-rollback
# health check with "LookupError: unknown encoding: idna" (socket.getaddrinfo
# imports encodings.idna on first use). Pre-load what the post-swap steps need.
import encodings.idna  # noqa: E402,F401  (also loads stringprep and unicodedata)
# Same reason: modules that functions below import lazily (rollback, locking,
# health, error reporting) are loaded up front. POSIX-only ones are optional so
# the module still imports on the Windows development host.
import errno  # noqa: E402,F401
import signal  # noqa: E402,F401
import traceback  # noqa: E402,F401
import urllib.parse  # noqa: E402,F401
try:
    import fcntl  # noqa: E402,F401
    import pwd  # noqa: E402,F401
except ImportError:  # pragma: no cover - Windows development host only
    pass

DEFAULT_APP = '/opt/projectapp/app'
DEFAULT_DATA = '/opt/projectapp/data'
DEFAULT_RUNTIME = '/opt/projectapp/runtime'
SERVICE_NAME = 'projectapp'
DEFAULT_SVC_USER = 'projectapp'
PRODUCT_NAME = '系統架構科工作管理平台'

# X.YYY.Z with every component capped at 0..999 (Bash compares the same
# ranges with plain integer arithmetic; see patch.sh VER_RE).
VERSION_RE = re.compile(r'([0-9]{1,3})\.([0-9]{3})\.([0-9]{1,3})')
# install.conf values are read back by bash; keep them to a shell-inert set.
CONF_VALUE_RE = re.compile(r'[A-Za-z0-9._/:+@-]*')
CONF_KEYS = ('VERSION', 'BUILD', 'RELEASE', 'INSTALL_TIME', 'UPDATED_TIME', 'API_PORT', 'BIND',
             'SVC_USER', 'SVC_GROUP', 'APP_DIR', 'DATA_DIR', 'RUNTIME_DIR', 'DB_DIR',
             'DATABASE_PATH', 'ATTACHMENTS_DIR', 'BACKUP_DIR', 'CONFIG_FILE', 'SERVICE_NAME')
UNIT_KEYS = ('VERSION', 'SVC_USER', 'SVC_GROUP', 'APP_DIR', 'DATA_DIR', 'RUNTIME_DIR', 'CONFIG_FILE')
RUNTIME_PREFIX = 'runtime/'
JOURNAL_NAME = 'install_txn.json'
RUN_TOKEN = '/run/projectapp-txn-start'
TXN_FORMAT = 'projectapp-txn-1'
BACKUP_NAME_RE = re.compile(r'(patch|install)_backup_[0-9]{14}_[0-9]{1,12}')
RELEASE_LINK_RE = re.compile(r'releases/[0-9]{1,3}\.[0-9]{3}\.[0-9]{1,3}-[0-9a-f]{12}')
RELEASE_NAME_RE = re.compile(r'[0-9]{1,3}\.[0-9]{3}\.[0-9]{1,3}-[0-9a-f]{12}')
SERVICE_USER_RE = re.compile(r'[a-z_][a-z0-9_-]{0,31}')
# Names directly under DATA_DIR that the service-owned database/attachment
# directories must never use (they belong to root).
RESERVED_DATA_NAMES = {'install.conf', 'config.json', JOURNAL_NAME, 'patch_audit.log', 'install_audit.log',
                       # V2-32 automatic backup (tools/auto_backup.py)
                       'auto-backups', 'auto_backup.json', 'auto_backup_status.json', 'auto_backup_audit.log',
                       # V2-28 parsing sandbox switch (tools/extract_sandbox.py)
                       'extract_sandbox.json'}

# Fixed manual-rollback entry. Static text: every value comes from the data
# files next to it (install.conf copy, txn.json), never from generated code.
ROLLBACK_SCRIPT = r'''#!/bin/bash
# ProjectApp fixed rollback entry (static text, not generated per run).
# Restores the pre-change state recorded in txn.json next to this file. It
# takes the same install/patch lock and refuses a backup that does not belong
# to the open transaction or to the version currently installed. A rollback
# after a committed run needs --accept-data-loss when the database changed,
# and always refuses when attachments changed (manual restore instead).
set -euo pipefail
umask 077
export LC_ALL=C PATH=/usr/sbin:/usr/bin:/sbin:/bin
unset PYTHONHOME PYTHONPATH PYTHONSTARTUP LD_PRELOAD LD_AUDIT LD_LIBRARY_PATH
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
if [[ $EUID -ne 0 && "${PROJECTAPP_ALLOW_NONROOT:-0}" != 1 ]]; then
    echo 'Run as root: sudo bash ROLLBACK_NOW.sh' >&2; exit 10
fi
runtime=""
while IFS= read -r candidate || [[ -n "$candidate" ]]; do
    [[ "$candidate" =~ ^/[A-Za-z0-9._/:+@-]*$ && ! -L "$candidate" ]] || continue
    if [[ -x "$candidate/bin/python3" ]] && "$candidate/bin/python3" -I -B -c 'import json, sqlite3, fcntl' 2>/dev/null; then
        runtime=$candidate; break
    fi
done < "$here/RECOVERY_RUNTIMES"
if [[ -z "$runtime" ]]; then
    echo 'No usable Python runtime is left (see RECOVERY_RUNTIMES). Recover with the installation package:' >&2
    echo "  sudo bash <extracted package>/INSTALL.sh --production --recover --data-dir $(dirname -- "$here") --backup $here $*" >&2
    exit 12
fi
exec "$runtime/bin/python3" -I -B "$here/layout.py" rollback --backup "$here" "$@"
'''


class LayoutError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------- environment
def euid():
    return os.geteuid() if hasattr(os, 'geteuid') else None


def test_mode():
    """Non-root test runs (PROJECTAPP_ALLOW_NONROOT=1). Overrides of the
    systemctl command, the /run token and kill points are honoured only here."""
    return euid() not in (None, 0) and os.environ.get('PROJECTAPP_ALLOW_NONROOT') == '1'


def systemctl_command():
    if test_mode() and os.environ.get('PROJECTAPP_SYSTEMCTL'):
        return shlex.split(os.environ['PROJECTAPP_SYSTEMCTL'])
    return ['/usr/bin/systemctl']


def run_token_path():
    if test_mode() and os.environ.get('PROJECTAPP_RUN_TOKEN'):
        return os.environ['PROJECTAPP_RUN_TOKEN']
    return RUN_TOKEN


def kill_point(name):
    """Test-only crash injection (SIGKILL of this process) at a named step.
    With PROJECTAPP_TEST_KILL_PARENT=1 a calling patch.sh (bash) dies too,
    which simulates a crash of the whole run."""
    if test_mode() and os.environ.get('PROJECTAPP_TEST_KILL_AT') == name:
        if os.environ.get('PROJECTAPP_TEST_KILL_PARENT') == '1':
            try:
                parent = Path('/proc/%d/comm' % os.getppid()).read_text().strip()
            except OSError:
                parent = ''
            if parent == 'bash':
                os.kill(os.getppid(), 9)
        os.kill(os.getpid(), 9)


# ---------------------------------------------------------------- versions
def parse_version(value):
    match = VERSION_RE.fullmatch(value or '') if isinstance(value, str) else None
    if not match:
        raise LayoutError(11, 'Version must use the X.YYY.Z format (each part 0..999).')
    return tuple(int(part) for part in match.groups())


def compare_versions(left, right):
    a, b = parse_version(left), parse_version(right)
    return (a > b) - (a < b)


def read_version_file(path):
    raw = Path(path).read_bytes()
    if raw.startswith(b'\xef\xbb\xbf'):
        raise LayoutError(11, 'version.json must not contain a UTF-8 BOM.')
    try:
        value = json.loads(raw.decode('utf-8'))
    except (UnicodeError, ValueError):
        raise LayoutError(11, 'version.json is not valid UTF-8 JSON.') from None
    if not isinstance(value, dict) or not isinstance(value.get('version'), str):
        raise LayoutError(11, 'version.json must contain a version string.')
    parse_version(value['version'])
    return value['version']


def release_dir_name(version, build):
    parse_version(version)
    if not re.fullmatch('[0-9a-f]{64}', build or ''):
        raise LayoutError(11, 'Invalid build identifier.')
    return version + '-' + build[:12]


def stamp(now=None):
    """yyyymmddHHMM in local time (package names, backup directories)."""
    return (now or datetime.now()).strftime('%Y%m%d%H%M')


def full_package_name(version, now=None):
    parse_version(version)
    return 'ProjectApp_v' + version + '-full_' + stamp(now)


def patch_package_name(version, now=None):
    parse_version(version)
    return 'ProjectApp_v' + version + '-patch_' + stamp(now)


# ---------------------------------------------------------------- paths
def clean_absolute(value, label, min_parts=3):
    """Normalized absolute POSIX path: no '.', '..', '//', trailing '/', shell-inert characters."""
    if not isinstance(value, str) or not value.startswith('/'):
        raise LayoutError(12, label + ' must be an absolute POSIX path.')
    pure = PurePosixPath(value)
    if ('..' in pure.parts or '.' in value.split('/') or str(pure) != value or not CONF_VALUE_RE.fullmatch(value)
            or len(pure.parts) < min_parts):
        raise LayoutError(12, label + ' must be a normalized dedicated path (no .., spaces or root-level dirs).')
    return str(pure)


_clean_absolute = clean_absolute  # backwards-compatible name


def _overlap(a, b):
    a, b = PurePosixPath(a), PurePosixPath(b)
    return a == b or a in b.parents or b in a.parents


def inside(child, parent):
    return PurePosixPath(parent) in PurePosixPath(child).parents


def resolve_layout(app=None, data=None, runtime=None, environ=None, conf_loader=None):
    """Return (layout dict, existing install.conf dict or None).

    Precedence: explicit argument > PROJECTAPP_* environment > default. When the
    data directory already holds install.conf, its APP_DIR / RUNTIME_DIR are
    kept; a different explicit request is refused instead of moving the install.
    """
    environ = os.environ if environ is None else environ
    conf_loader = conf_loader or read_conf_if_present
    data_dir = clean_absolute(data or environ.get('PROJECTAPP_DATA') or DEFAULT_DATA, 'Data directory')
    existing = conf_loader(str(PurePosixPath(data_dir) / 'install.conf'))
    requested = {
        'APP_DIR': app or environ.get('PROJECTAPP_APP'),
        'RUNTIME_DIR': runtime or environ.get('PROJECTAPP_RUNTIME'),
    }
    result = {'DATA_DIR': data_dir}
    for key, default in (('APP_DIR', DEFAULT_APP), ('RUNTIME_DIR', DEFAULT_RUNTIME)):
        if existing:
            kept = clean_absolute(existing[key], key)
            if requested[key] and clean_absolute(requested[key], key) != kept:
                raise LayoutError(12, key + ' differs from the existing installation; existing installs are '
                                  'never moved automatically. Keep the recorded location.')
            result[key] = kept
        else:
            result[key] = clean_absolute(requested[key] or default, key)
    if existing and existing.get('DATA_DIR') and existing['DATA_DIR'] != data_dir:
        raise LayoutError(12, 'install.conf DATA_DIR does not match the directory it was read from.')
    for left, right in (('APP_DIR', 'DATA_DIR'), ('APP_DIR', 'RUNTIME_DIR'), ('DATA_DIR', 'RUNTIME_DIR')):
        if _overlap(result[left], result[right]):
            raise LayoutError(12, left + ' and ' + right + ' must not overlap.')
    data_path = PurePosixPath(data_dir)
    result.update({
        'DB_DIR': (existing or {}).get('DB_DIR') or str(data_path / 'db'),
        'ATTACHMENTS_DIR': (existing or {}).get('ATTACHMENTS_DIR') or str(data_path / 'attachments'),
        'BACKUP_DIR': (existing or {}).get('BACKUP_DIR') or str(data_path / 'backups'),
        'CONFIG_FILE': (existing or {}).get('CONFIG_FILE') or str(data_path / 'config.json'),
    })
    for key in ('BACKUP_DIR', 'CONFIG_FILE'):
        value = clean_absolute(result[key], key)
        if PurePosixPath(value).parent != data_path:
            raise LayoutError(12, key + ' must be directly inside DATA_DIR.')
    return result, existing


def check_data_slot(path, data_dir, backup_dir, label):
    """A service-owned directory (db / attachments) inside DATA_DIR must not
    take a root-owned name (install.conf, backups, journal, audit logs, ...)."""
    relative = PurePosixPath(path).relative_to(PurePosixPath(data_dir))
    first = relative.parts[0]
    if (first in RESERVED_DATA_NAMES or first == PurePosixPath(backup_dir).name or BACKUP_NAME_RE.fullmatch(first)
            or first.startswith('.') or first.endswith('.log')):
        raise LayoutError(12, label + ' uses a name reserved for root-owned installer files in DATA_DIR.')


# ---------------------------------------------------------------- trust checks
def _owner_name(owner):
    return 'root' if owner == 0 else 'the installing account'


def check_ancestors(path, label):
    """Every existing ancestor: real directory, owned by root/euid, and not
    group/other-writable unless sticky (a /tmp-like shared parent)."""
    if euid() is None:
        return
    trusted = {0, euid()}
    for parent in PurePosixPath(path).parents:
        info = os.lstat(parent)
        if (stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode) or info.st_uid not in trusted
                or (info.st_mode & 0o022 and not info.st_mode & stat.S_ISVTX)):
            raise LayoutError(12, label + ': an ancestor directory is a symlink, foreign-owned or writable by others.')


def check_trusted_dir(path, label, owner=None, ancestors=True):
    """Managed root directory: real dir, owned by euid (root), not g/o-writable."""
    if euid() is None:
        return
    owner = euid() if owner is None else owner
    info = os.lstat(path)
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
        raise LayoutError(12, label + ' must be a real directory (not a symlink).')
    if info.st_uid != owner or info.st_mode & 0o022:
        raise LayoutError(12, label + ' must be owned by ' + _owner_name(owner) +
                          ' and not group/other-writable; fix it manually (the installer never takes over foreign directories).')
    if ancestors:
        check_ancestors(path, label)


def check_trusted_file(path, label, owner=None):
    if euid() is None:
        return
    owner = euid() if owner is None else owner
    info = os.lstat(path)
    if (stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode) or info.st_uid != owner
            or info.st_nlink != 1 or info.st_mode & 0o022):
        raise LayoutError(12, label + ' must be a regular file owned by ' + _owner_name(owner) +
                          ', without hard links, not group/other-writable.')


def check_no_symlink_components(path, stop_at=None):
    """lstat every existing component of path (below stop_at): never a symlink."""
    path = PurePosixPath(path)
    chain = [path, *path.parents]
    for item in chain:
        if stop_at is not None and (item == PurePosixPath(stop_at) or item in PurePosixPath(stop_at).parents):
            break
        try:
            info = os.lstat(item)
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode):
            raise LayoutError(12, 'Path component is a symbolic link: ' + str(item))


def ensure_directory(path, mode, uid=None, gid=None, *, may_exist_owner=None):
    """Create path (parent must already be trusted) and set mode/owner through
    the opened descriptor (O_NOFOLLOW|O_DIRECTORY), never by path after close.

    A directory created now gets ``uid``/``gid``. An existing one keeps its
    owner, which must be in ``may_exist_owner`` (default: the intended owner);
    the installer never takes over an existing foreign directory.
    Returns True when the directory was created by this call.
    """
    created = False
    try:
        os.mkdir(path, 0o700)
        created = True
    except FileExistsError:
        pass
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        info = os.fstat(descriptor)
        if hasattr(os, 'fchown') and euid() is not None:
            wanted = euid() if uid is None else uid
            allowed = {wanted} if may_exist_owner is None else set(may_exist_owner)
            if created:
                if uid is not None and euid() == 0:
                    os.fchown(descriptor, uid, -1 if gid is None else gid)
            elif info.st_uid not in allowed:
                raise LayoutError(12, 'Existing directory has an unexpected owner: ' + str(path))
        os.fchmod(descriptor, mode) if hasattr(os, 'fchmod') else os.chmod(path, mode)
    finally:
        os.close(descriptor)
    return created


def fsync_dir(path):
    if not hasattr(os, 'O_DIRECTORY'):
        return
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


# ---------------------------------------------------------------- install.conf
def format_conf(values):
    missing = [key for key in CONF_KEYS if key not in values]
    if missing:
        raise LayoutError(13, 'install.conf is missing keys: ' + ', '.join(missing))
    lines = ['# ProjectApp install.conf - written by the installer, read back by patch.sh.',
             '# KEY=VALUE, no quoting/expansion. Do not edit by hand.']
    for key in CONF_KEYS:
        value = str(values[key])
        if not CONF_VALUE_RE.fullmatch(value):
            raise LayoutError(13, 'install.conf value for ' + key + ' contains unsupported characters.')
        lines.append(key + '=' + value)
    return '\n'.join(lines) + '\n'


def parse_conf(text):
    values = {}
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        key, sep, value = line.partition('=')
        if not sep or key not in CONF_KEYS or key in values or not CONF_VALUE_RE.fullmatch(value):
            raise LayoutError(13, 'install.conf line %d is invalid.' % number)
        values[key] = value
    missing = [key for key in CONF_KEYS if key not in values]
    if missing:
        raise LayoutError(13, 'install.conf is missing keys: ' + ', '.join(missing))
    parse_version(values['VERSION'])
    if not values['API_PORT'].isdigit() or not 1024 <= int(values['API_PORT']) <= 65535:
        raise LayoutError(13, 'install.conf API_PORT is invalid.')
    if not SERVICE_USER_RE.fullmatch(values['SVC_USER']) or values['SVC_USER'] == 'root':
        raise LayoutError(13, 'install.conf SVC_USER is invalid.')
    for key in ('APP_DIR', 'DATA_DIR', 'RUNTIME_DIR', 'DB_DIR', 'DATABASE_PATH', 'ATTACHMENTS_DIR', 'BACKUP_DIR',
                'CONFIG_FILE'):
        try:
            clean_absolute(values[key], key, min_parts=2)
        except LayoutError:
            raise LayoutError(13, 'install.conf ' + key + ' is not a normalized absolute path.') from None
    return values


def open_dir_nofollow(path):
    """Open a directory walking from '/' with O_NOFOLLOW on every component:
    a symlink anywhere in the path fails instead of being followed."""
    descriptor = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in PurePosixPath(path).parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def read_trusted_text(path, label, owner=None, limit=1 << 20):
    """Shared safe reader for root-owned control files (install.conf, journal,
    txn.json, INSTALLATION.json): trusted ancestors, O_NOFOLLOW open, then
    fstat of the opened file (regular, owner, one link, not g/o-writable)."""
    if not hasattr(os, 'O_DIRECTORY'):
        return Path(path).read_text(encoding='utf-8')
    check_ancestors(path, label)
    directory = open_dir_nofollow(PurePosixPath(path).parent)
    try:
        descriptor = os.open(PurePosixPath(path).name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    except OSError:
        raise LayoutError(12, label + ' cannot be opened safely (missing or a symbolic link).') from None
    finally:
        os.close(directory)
    with os.fdopen(descriptor, 'rb') as stream:
        info = os.fstat(stream.fileno())
        wanted = euid() if owner is None else owner
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != wanted or info.st_nlink != 1
                or info.st_mode & 0o022):
            raise LayoutError(12, label + ' must be a regular file owned by ' + _owner_name(wanted) +
                              ', without hard links, not group/other-writable.')
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise LayoutError(12, label + ' is too large.')
    return data.decode('utf-8')


def read_conf_if_present(path):
    """install.conf through the shared safe reader (V1001R-14)."""
    if not os.path.lexists(path):
        return None
    return parse_conf(read_trusted_text(path, 'install.conf'))


def write_private_atomic(path, text, mode=0o644):
    """Temp file (O_EXCL|O_NOFOLLOW) + fchmod + fsync + rename + directory fsync.
    Only used in root-owned, non-writable-by-others directories."""
    path = Path(path)
    temporary = path.with_name('.' + path.name + '.tmp-' + str(os.getpid()))
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(temporary, flags, mode)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8', newline='\n') as stream:
            if hasattr(os, 'fchmod'):
                os.fchmod(stream.fileno(), mode)
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        if not hasattr(os, 'fchmod'):
            os.chmod(temporary, mode)
        os.replace(temporary, path)
        fsync_dir(path.parent)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def now_iso():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


# ---------------------------------------------------------------- systemd
def render_unit(template, values, run_token=None):
    text = template
    for key in UNIT_KEYS:
        value = str(values[key])
        if not CONF_VALUE_RE.fullmatch(value) or not value:
            raise LayoutError(13, 'Unit value for ' + key + ' is invalid.')
        text = text.replace('@' + key + '@', value)
    token = run_token or run_token_path()
    if not CONF_VALUE_RE.fullmatch(token) or not token.startswith('/'):
        raise LayoutError(13, 'Unit run token path is invalid.')
    text = text.replace('@RUN_TOKEN@', token).replace('@JOURNAL@', str(PurePosixPath(values['DATA_DIR']) / JOURNAL_NAME))
    if re.search(r'@[A-Z_]+@', text):
        raise LayoutError(13, 'Unit template contains an unknown placeholder.')
    if values['SVC_USER'] == 'root':
        raise LayoutError(13, 'The service must not run as root.')
    return text


UNIT_MANAGED_HEADER = '# Managed by the ProjectApp installer'


def unit_installation(unit_path):
    """The installation an existing projectapp.service belongs to:
    {'APP_DIR', 'DATA_DIR', 'RUNTIME_DIR'} read from its managed header and
    Environment= lines; None when the unit is not ours (V3D-03)."""
    text = read_trusted_text(unit_path, 'projectapp.service')
    if not text.startswith(UNIT_MANAGED_HEADER):
        return None
    found = {}
    for line in text.splitlines():
        for key, name in (('APP_DIR', 'PROJECTAPP_APP'), ('DATA_DIR', 'PROJECTAPP_DATA'),
                          ('RUNTIME_DIR', 'PROJECTAPP_RUNTIME')):
            if line.startswith('Environment=' + name + '='):
                found[key] = line.split('=', 2)[2].strip()
    work = [line.split('=', 1)[1].strip() for line in text.splitlines() if line.startswith('WorkingDirectory=')]
    if set(found) != {'APP_DIR', 'DATA_DIR', 'RUNTIME_DIR'} or work != [found['APP_DIR'] + '/current']:
        return None
    return found


def check_unit_belongs(unit_path, app_dir, data_dir, runtime_dir):
    """V3D-03: the fixed service name belongs to exactly one installation. An
    existing unit of another installation, or one not written by this
    installer, is never stopped or rewritten."""
    if unit_path is None or not os.path.lexists(unit_path):
        return
    owner = unit_installation(unit_path)
    wanted = {'APP_DIR': str(app_dir), 'DATA_DIR': str(data_dir), 'RUNTIME_DIR': str(runtime_dir)}
    if owner is None:
        raise LayoutError(12, '%s exists but was not written by the ProjectApp installer (or was edited); it is '
                          'not stopped or changed. Remove or rename it yourself if it is obsolete.' % unit_path)
    if owner != wanted:
        raise LayoutError(12, '%s belongs to another installation (APP_DIR=%s, DATA_DIR=%s, RUNTIME_DIR=%s); this '
                          'one (APP_DIR=%s, DATA_DIR=%s, RUNTIME_DIR=%s) is refused and nothing was stopped or '
                          'changed. One host runs one ProjectApp installation.'
                          % (unit_path, owner['APP_DIR'], owner['DATA_DIR'], owner['RUNTIME_DIR'],
                             wanted['APP_DIR'], wanted['DATA_DIR'], wanted['RUNTIME_DIR']))


# ---------------------------------------------------------------- integrity
def sha256(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _tree_members(root):
    found = set()
    owner = euid()
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [name for name in dirs if name != '__pycache__']  # U73: byte-code caches are not members
        for name in dirs:
            path = Path(directory) / name
            if path.is_symlink():
                raise LayoutError(11, 'Directory symlinks are not allowed in an installed tree.')
            info = path.lstat()
            if owner is not None and (info.st_mode & 0o022 or info.st_uid != owner):
                raise LayoutError(11, 'Unsafe installed directory permissions or owner.')
        for name in files:
            found.add((Path(directory) / name).relative_to(root).as_posix())
    return found


def _check_record(path, record):
    if record['kind'] == 'link':
        if not path.is_symlink() or os.readlink(path) != record['target']:
            raise LayoutError(11, 'Symlink drift in installed tree.')
    elif path.is_symlink() or not path.is_file() or sha256(path) != record['sha256']:
        raise LayoutError(11, 'Installed file integrity failure.')
    if euid() is not None and not path.is_symlink():
        info = path.lstat()
        if info.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_IWGRP | stat.S_IWOTH) or info.st_uid != euid():
            raise LayoutError(11, 'Unsafe installed file permissions or owner.')


def _split(manifest):
    records = manifest['files']
    computed = hashlib.sha256(json.dumps(records, sort_keys=True).encode()).hexdigest()
    if manifest.get('build') != computed:
        raise LayoutError(11, 'Build identifier does not match the payload manifest.')
    app_records = {k: v for k, v in records.items() if not k.startswith(RUNTIME_PREFIX)}
    runtime_records = {k[len(RUNTIME_PREFIX):]: v for k, v in records.items() if k.startswith(RUNTIME_PREFIX)}
    return app_records, runtime_records


def _check_subset(root, subset):
    for name, record in subset.items():
        part = PurePosixPath(name)
        if part.is_absolute() or '..' in part.parts:
            raise LayoutError(11, 'Unsafe manifest path.')
        _check_record(Path(root) / name, record)


def verify_release_part(release, manifest):
    """Release directory = payload minus runtime/ (+ MANIFEST.json, SHA256SUMS)."""
    if Path(release).is_symlink():
        raise LayoutError(11, 'Release must be a real directory.')
    app_records, _ = _split(manifest)
    if _tree_members(release) != set(app_records) | {'MANIFEST.json', 'SHA256SUMS'}:
        raise LayoutError(11, 'Unexpected or missing release members.')
    _check_subset(release, app_records)


def verify_runtime_part(runtime, manifest):
    _, runtime_records = _split(manifest)
    if Path(runtime).is_symlink() or not Path(runtime).is_dir() or _tree_members(runtime) != set(runtime_records):
        raise LayoutError(11, 'Unexpected or missing runtime members.')
    _check_subset(runtime, runtime_records)


def verify_installed(release, runtime, manifest):
    """Verify an installed release directory and the separate runtime dir."""
    verify_release_part(release, manifest)
    verify_runtime_part(runtime, manifest)
    return manifest


def read_manifest(release):
    return json.loads((Path(release) / 'MANIFEST.json').read_text(encoding='utf-8'))


# ---------------------------------------------------------------- runtime ops
def check_port_free(bind, port):
    family = socket.AF_INET6 if ':' in bind else socket.AF_INET
    with socket.socket(family) as sock:
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((bind, int(port)))
        except OSError:
            return False
    return True


def database_holders(database):
    """PIDs (not this process) that have the SQLite database or one of its
    sidecar files open, from /proc/<pid>/fd (V3C-03). As root every process is
    visible; a process that cannot be inspected is skipped (non-root tests)."""
    targets = set()
    for suffix in ('', '-journal', '-wal', '-shm'):
        try:
            info = os.stat(str(database) + suffix)
        except OSError:
            continue
        targets.add((info.st_dev, info.st_ino))
    if not targets or not os.path.isdir('/proc'):
        return []
    holders = []
    for entry in os.listdir('/proc'):
        if not entry.isdigit() or int(entry) == os.getpid():
            continue
        fd_dir = '/proc/%s/fd' % entry
        try:
            names = os.listdir(fd_dir)
        except OSError:
            continue
        for name in names:
            try:
                info = os.stat(fd_dir + '/' + name)
            except OSError:
                continue
            if (info.st_dev, info.st_ino) in targets:
                holders.append(int(entry))
                break
    return sorted(holders)


def ensure_quiesced(bind, port, database, service=SERVICE_NAME):
    """V3C-03 / V3D-02: before the database is copied or overwritten and
    before any release switch, the production port must be free and no
    process may hold the database open. A process outside the unit (for
    example a foreground RUN.sh serve) is never stopped automatically."""
    if bind and port and not check_port_free(bind, port):
        raise LayoutError(17, 'Port %s:%s is still in use although %s is stopped: a process outside the unit (for '
                          'example a foreground RUN.sh serve) is serving. Nothing was copied or overwritten; stop '
                          'that process yourself (it is never killed automatically) and rerun.' % (bind, port, service))
    holders = database_holders(database) if database else []
    if holders:
        raise LayoutError(17, 'The database %s is still open by process(es) %s outside %s. Nothing was copied or '
                          'overwritten; stop them yourself and rerun.'
                          % (database, ','.join(str(pid) for pid in holders[:10]), service))


def free_port(bind):
    family = socket.AF_INET6 if ':' in bind else socket.AF_INET
    with socket.socket(family) as sock:
        sock.bind((bind, 0))
        return sock.getsockname()[1]


def health_snapshot(bind, port, host, timeout=5.0):
    """Return the /api/health JSON dict or None."""
    connection = http.client.HTTPConnection(bind, int(port), timeout=timeout)
    try:
        connection.request('GET', '/api/health', headers={'Host': host, 'X-Forwarded-Proto': 'https'})
        response = connection.getresponse()
        body = response.read(65536)
        if response.status != 200:
            return None
        value = json.loads(body.decode('utf-8'))
        return value if isinstance(value, dict) else None
    except (OSError, ValueError, http.client.HTTPException):
        return None
    finally:
        connection.close()


def health_release_version(bind, port, host, timeout=5.0):
    value = health_snapshot(bind, port, host, timeout)
    return value.get('release_version') if value else None


def health_matches(value, version, build=None):
    return (isinstance(value, dict) and value.get('release_version') == version
            and (build is None or value.get('build') == build) and value.get('mode') == 'production')


def public_host(config_path):
    # Root reads the service-owned config only to learn the Host header value.
    from urllib.parse import urlsplit
    value = read_service_config(config_path)
    host = urlsplit(value['public_origin']).hostname
    if not host:
        raise LayoutError(13, 'public_origin has no host.')
    return host


def wait_health(bind, port, host, expected, seconds, build=None):
    """Wait until /api/health reports release_version == expected and, when
    given, the same build, in production mode. Returns (ok, last snapshot)."""
    deadline = time.monotonic() + seconds
    seen = None
    while True:
        seen = health_snapshot(bind, port, host)
        if health_matches(seen, expected, build):
            return True, seen
        if time.monotonic() >= deadline:
            return False, seen
        time.sleep(1)


def _open_file_nofollow(path, flags=os.O_RDONLY):
    """Open path with every directory component opened O_NOFOLLOW from '/'
    and the final component O_NOFOLLOW (V1001R-03/04: the checked object is
    the opened object). Returns a file descriptor."""
    if not hasattr(os, 'O_DIRECTORY'):
        return os.open(path, flags)
    directory = open_dir_nofollow(PurePosixPath(path).parent)
    try:
        return os.open(PurePosixPath(path).name, flags | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    finally:
        os.close(directory)


def read_service_config(path, owners=None):
    """Read the service-owned config.json (or the root-owned transaction
    snapshot) without following links (root side)."""
    try:
        descriptor = _open_file_nofollow(path)
    except OSError:
        raise LayoutError(13, 'Cannot open the protected configuration file.') from None
    with os.fdopen(descriptor, 'rb') as stream:
        info = os.fstat(stream.fileno())
        snapshot = euid() is not None and info.st_uid == euid() and not info.st_mode & 0o137
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or (
                euid() is not None and info.st_mode & 0o077 and not snapshot) \
                or (owners is not None and info.st_uid not in owners and not snapshot):
            raise LayoutError(13, 'Configuration must be a private regular file without hard links.')
        content = stream.read(65537)
    if len(content) > 65536:
        raise LayoutError(13, 'Configuration exceeds the size limit.')
    try:
        value = json.loads(content)
    except (ValueError, UnicodeError):
        raise LayoutError(13, 'Invalid configuration JSON.') from None
    if not isinstance(value, dict) or not isinstance(value.get('environment'), dict):
        raise LayoutError(13, 'Configuration structure is invalid.')
    return value


def config_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()


def sqlite_url_path(url):
    if not isinstance(url, str) or not url.startswith('sqlite:////') or '?' in url or '#' in url:
        raise LayoutError(13, 'DATABASE_URL must be an absolute sqlite:////path URL without options.')
    return clean_absolute(url[len('sqlite:///'):], 'DATABASE_URL path', min_parts=2)


def snapshot_name(txn_id):
    return '.txn-config-' + txn_id + '.json'


def write_config_snapshot(data_dir, txn_id, value, gid=None):
    """Root-owned copy of the verified configuration that every transaction
    step uses (V1001R-10): 0640 root:<service group> when root, else 0600."""
    path = Path(data_dir) / snapshot_name(txn_id)
    temporary = path.with_name(path.name + '.tmp-' + str(os.getpid()))
    mode = 0o640 if euid() == 0 else 0o600
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
            if euid() == 0 and gid is not None:
                os.fchown(stream.fileno(), 0, gid)
            if hasattr(os, 'fchmod'):
                os.fchmod(stream.fileno(), mode)
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        fsync_dir(path.parent)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    return str(path)


def remove_config_snapshot(txn):
    if txn.get('config_snapshot'):
        try:
            os.unlink(txn['config_snapshot'])
        except FileNotFoundError:
            pass


def database_handle(database):
    """(dir_fd, file_fd, stat) of the database opened without following links."""
    directory = open_dir_nofollow(PurePosixPath(database).parent)
    try:
        descriptor = os.open(PurePosixPath(database).name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=directory)
    except BaseException:
        os.close(directory)
        raise
    info = os.fstat(descriptor)
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        os.close(descriptor)
        os.close(directory)
        raise LayoutError(13, 'The database must be a regular file without hard links.')
    return directory, descriptor, info


def database_identity(database):
    if not hasattr(os, 'O_DIRECTORY'):
        info = os.stat(database)
        return [info.st_dev, info.st_ino]
    directory, descriptor, info = database_handle(database)
    os.close(descriptor)
    os.close(directory)
    return [info.st_dev, info.st_ino]


def database_sha256(database):
    if not hasattr(os, 'O_DIRECTORY'):
        return sha256(database)
    directory, descriptor, _ = database_handle(database)
    try:
        with os.fdopen(descriptor, 'rb') as stream:
            return hashlib.file_digest(stream, 'sha256').hexdigest()
    finally:
        os.close(directory)


def reconcile(conf, config_path=None, owners=None, require_database=True):
    """install.conf and the (snapshot) configuration must name the same
    database, attachments, bind and port (V1001-10); the database must exist."""
    value = read_service_config(config_path or conf['CONFIG_FILE'], owners)
    environment = value['environment']
    database = sqlite_url_path(environment.get('DATABASE_URL'))
    mismatches = [name for name, left, right in (
        ('DATABASE_PATH', database, conf['DATABASE_PATH']),
        ('ATTACHMENTS_DIR', environment.get('WORKBOARD_STORAGE'), conf['ATTACHMENTS_DIR']),
        ('API_PORT', str(value.get('port')), conf['API_PORT']),
        ('BIND', value.get('bind'), conf['BIND']),
        ('DB_DIR', str(PurePosixPath(database).parent), conf['DB_DIR'])) if left != right]
    if mismatches:
        raise LayoutError(13, 'config.json and install.conf disagree on ' + ', '.join(mismatches) +
                          '; fix the configuration before upgrading (nothing was changed).')
    check_no_symlink_components(database)
    if os.path.lexists(database):
        database_identity(database)
    elif require_database:
        raise LayoutError(13, 'The configured database file does not exist; an upgrade never creates it.')
    return {'database': database, 'config_sha256': config_sha256(value), 'value': value}


def _write_all(descriptor, data):
    """Write every byte or raise (V1001S-08): short writes are continued,
    a zero-length write is an error (no progress)."""
    view = memoryview(data)
    while view:
        written = os.write(descriptor, view)
        if written <= 0:
            raise OSError(28, 'write made no progress')
        view = view[written:]


def _copy_fd(reader, writer):
    total = 0
    while True:
        chunk = reader.read(1024 * 1024)
        if not chunk:
            return total
        _write_all(writer, chunk)
        total += len(chunk)


def _fd_sha256(descriptor):
    os.lseek(descriptor, 0, os.SEEK_SET)
    digest = hashlib.sha256()
    while True:
        chunk = os.read(descriptor, 1024 * 1024)
        if not chunk:
            return digest.hexdigest()
        digest.update(chunk)


def sqlite_integrity_ok(path):
    check = sqlite3.connect('file:' + Path(path).as_posix() + '?mode=ro', uri=True)
    try:
        return check.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    finally:
        check.close()


def sqlite_backup(source, destination, owner=None):
    """Copy the database into a new root-owned file (see
    sqlite_backup_with_identity). Returns the sha256 of the copy."""
    return sqlite_backup_with_identity(source, destination, owner)[0]


def sqlite_backup_with_identity(source, destination, owner=None):
    """Linux: the source is opened through O_NOFOLLOW descriptors (the file
    that was checked is the file that is read), a hot journal refuses, the
    copy is raw from that descriptor with the service stopped, size/mtime must
    not change during the copy, and the copy must pass integrity_check."""
    source, destination = Path(source), Path(destination)
    if destination.exists() or destination.is_symlink():
        raise LayoutError(12, 'Backup destination already exists.')
    if not hasattr(os, 'O_DIRECTORY'):  # Windows development fallback (backup API)
        src = sqlite3.connect('file:' + source.as_posix() + '?mode=ro', uri=True)
        try:
            dst = sqlite3.connect(str(destination))
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        info = os.stat(source)
        identity = [info.st_dev, info.st_ino]
    else:
        directory, descriptor, info = database_handle(source)
        try:
            if owner is not None and info.st_uid not in {owner, 0}:
                raise LayoutError(13, 'The database file has an unexpected owner.')
            for suffix in ('-journal', '-wal'):
                try:
                    os.stat(source.name + suffix, dir_fd=directory, follow_symlinks=False)
                except FileNotFoundError:
                    continue
                raise LayoutError(13, 'A SQLite ' + suffix + ' file exists (interrupted writer); start the '
                                  'current version once so SQLite recovers it, then retry.')
            writer = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            try:
                with os.fdopen(descriptor, 'rb', closefd=False) as reader:
                    copied = _copy_fd(reader, writer)
                os.fsync(writer)
            finally:
                os.close(writer)
            after = os.fstat(descriptor)
            if (after.st_size, after.st_mtime_ns) != (info.st_size, info.st_mtime_ns) or copied != info.st_size:
                raise LayoutError(13, 'The database changed while it was copied; is another writer running?')
            identity = [info.st_dev, info.st_ino]
        finally:
            os.close(descriptor)
            os.close(directory)
    if not sqlite_integrity_ok(destination):
        raise LayoutError(13, 'Backup copy failed the SQLite integrity check.')
    fsync_dir(destination.parent)
    return sha256(destination), identity


def sqlite_restore(backup, database, uid=None, gid=None, expected_sha256=None):
    """Replace the database with a verified backup copy (service stopped).

    The new file is written inside a root-owned 0700 staging directory created
    in the database directory (same filesystem), with a full-write loop; before
    the rename its size, SHA-256 and PRAGMA integrity_check are verified
    (V1001S-08); owner/mode are set on the open descriptor and the rename is
    relative to directory descriptors opened without following links.
    """
    backup, database = Path(backup), Path(database)
    if not sqlite_integrity_ok(backup):
        raise LayoutError(13, 'Backup copy failed the SQLite integrity check.')
    expected = expected_sha256 or sha256(backup)
    size = os.stat(backup).st_size
    if not hasattr(os, 'O_DIRECTORY'):  # Windows development fallback
        temporary = database.with_name('.' + database.name + '.restore-' + str(os.getpid()))
        with open(backup, 'rb') as reader, open(temporary, 'xb') as writer:
            writer.write(reader.read())
        if sha256(temporary) != expected:
            os.unlink(temporary)
            raise LayoutError(13, 'Restored copy does not match the backup checksum.')
        for suffix in ('-journal', '-wal', '-shm'):
            stale = database.with_name(database.name + suffix)
            if stale.exists():
                stale.unlink()
        os.replace(temporary, database)
        return
    directory = open_dir_nofollow(database.parent)
    try:
        info = os.fstat(directory)
        if uid is not None and info.st_uid not in {uid, 0}:
            raise LayoutError(12, 'Database directory owner changed; restore refused.')
        stage_name = '.projectapp-restore-' + str(os.getpid())
        os.mkdir(stage_name, 0o700, dir_fd=directory)
        stage = os.open(stage_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
        try:
            if os.fstat(stage).st_uid != euid():
                raise LayoutError(12, 'Restore staging directory was replaced; restore refused.')
            writer = os.open('database', os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=stage)
            try:
                with open(backup, 'rb') as reader:
                    _copy_fd(reader, writer)
                os.fchmod(writer, 0o600)
                os.fsync(writer)
                if os.fstat(writer).st_size != size or _fd_sha256(writer) != expected:
                    raise LayoutError(13, 'The restored copy is incomplete (size/SHA-256 differ); nothing replaced.')
                staged_path = '/proc/self/fd/%d/database' % stage
                if not sqlite_integrity_ok(staged_path):
                    raise LayoutError(13, 'The restored copy failed PRAGMA integrity_check; nothing replaced.')
                if uid is not None and euid() == 0:
                    os.fchown(writer, uid, -1 if gid is None else gid)
            except BaseException:
                os.close(writer)
                try:
                    os.unlink('database', dir_fd=stage)
                except OSError:
                    pass
                raise
            os.close(writer)
            for suffix in ('-journal', '-wal', '-shm'):
                try:
                    os.unlink(database.name + suffix, dir_fd=directory)
                except FileNotFoundError:
                    pass
            os.replace('database', database.name, src_dir_fd=stage, dst_dir_fd=directory)
            os.fsync(directory)
        finally:
            os.close(stage)
            try:
                os.rmdir(stage_name, dir_fd=directory)
            except OSError:
                pass
    finally:
        os.close(directory)


def _attachments_walk(path, content):
    """Digest of the attachment tree walked without following links: root
    identity, relative path, type, size, mtime_ns and -- with content=True --
    the SHA-256 of every regular file. Any listing/reading error aborts
    (V1001S-05): a partial walk is never a proof."""
    def failed(error):
        raise LayoutError(16, 'The attachment directory cannot be listed completely (%s); automatic rollback '
                          'and commit decisions are refused.' % type(error).__name__)
    # V1001T-02: only a definite "does not exist" is "absent"; EACCES, EIO,
    # an unsearchable ancestor or any other error refuses.
    try:
        root = os.lstat(path)
    except FileNotFoundError:
        return 'absent'
    except OSError as error:
        failed(error)
    if stat.S_ISLNK(root.st_mode) or not stat.S_ISDIR(root.st_mode):
        raise LayoutError(16, 'The attachment directory is not a real directory.')
    if not os.access(path, os.R_OK | os.X_OK):
        raise LayoutError(16, 'The attachment directory cannot be traversed by this account.')
    digest = hashlib.sha256(json.dumps(['root', root.st_dev, root.st_ino]).encode())
    for directory, dirs, files in os.walk(path, followlinks=False, onerror=failed):
        dirs.sort()
        for name in sorted(dirs + files):
            entry = Path(directory) / name
            try:
                info = os.lstat(entry)
            except OSError as error:
                failed(error)
            record = [entry.relative_to(path).as_posix(), stat.S_IFMT(info.st_mode), info.st_size, info.st_mtime_ns]
            if content and stat.S_ISREG(info.st_mode):
                try:
                    descriptor = os.open(str(entry), os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
                except OSError as error:
                    failed(error)
                try:
                    opened = os.fstat(descriptor)
                    if (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
                        raise LayoutError(16, 'An attachment changed while it was read; decisions are refused.')
                    record.append(_fd_sha256(descriptor))
                except OSError as error:
                    failed(error)
                finally:
                    os.close(descriptor)
            digest.update(json.dumps(record).encode())
    return digest.hexdigest()


def attachments_digest(path):
    """'absent', or '<metadata digest>:<content digest>' (V3D-11: the content
    SHA-256 of every file is part of the proof, not only size and mtime)."""
    if not path:
        return 'absent'
    meta = _attachments_walk(path, content=False)
    if meta == 'absent':
        return 'absent'
    return meta + ':' + _attachments_walk(path, content=True)


def attachments_unchanged(path, recorded):
    """Size/mtime/type digest first (cheap: any difference refuses at once),
    then the content digest. A record without a content digest proves nothing."""
    if recorded is None:
        return True
    if recorded == 'absent' or not path:
        return attachments_digest(path) == 'absent'
    meta, _, content = str(recorded).partition(':')
    if not content:
        return False
    now = _attachments_walk(path, content=False)
    if now != meta:
        return False
    return _attachments_walk(path, content=True) == content


ACCESS_CHECK_PY = (
    'import os, sys\n'
    'bad = []\n'
    'for root in sys.argv[1:]:\n'
    '    for d, dirs, files in os.walk(root, onerror=lambda e: bad.append(str(e.filename))):\n'
    '        if not os.access(d, os.R_OK | os.X_OK): bad.append(d)\n'
    '        for f in files:\n'
    '            p = os.path.join(d, f)\n'
    '            if not os.path.islink(p) and not os.access(p, os.R_OK): bad.append(p)\n'
    'print("\\n".join(bad[:5]) or "ACCESS_OK"); sys.exit(1 if bad else 0)\n')


def normalize_tree_modes(root):
    """V1001U-02: directories 0755; regular files 0755 if owner-executable,
    else 0644 (whatever umask or archive the package came through)."""
    for directory, dirs, files in os.walk(root, followlinks=False):
        os.chmod(directory, 0o755)
        for name in files:
            path = Path(directory) / name
            if path.is_symlink():
                continue
            mode = os.lstat(path).st_mode
            os.chmod(path, 0o755 if mode & 0o100 else 0o644)


def fsync_tree(root):
    """fsync every regular file and directory under root (V1001R-13)."""
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in files:
            path = Path(directory) / name
            if path.is_symlink():
                continue
            descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        fsync_dir(directory)
    fsync_dir(Path(root).parent)


# ---------------------------------------------------------------- audit
def audit(data_dir, kind, **fields):
    """Append one line to DATA_DIR/<kind>_audit.log with fsync. Raises on any
    failure: a missing audit record fails the run (V1001-20)."""
    if kind not in ('patch', 'install'):
        raise LayoutError(13, 'Unknown audit kind.')
    path = PurePosixPath(data_dir) / (kind + '_audit.log')
    parts = [datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %z')]
    for key, value in fields.items():
        text = re.sub(r'[\x00-\x1f\x7f]', '?', str(value))
        parts.append(key + '=' + text)
    line = ('\t'.join(parts) + '\n').encode('utf-8')
    flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
    try:
        descriptor = os.open(str(path), flags, 0o600)
    except OSError:
        raise LayoutError(14, 'Cannot open the audit log ' + str(path)) from None
    try:
        info = os.fstat(descriptor)
        if euid() is not None and (not stat.S_ISREG(info.st_mode) or info.st_uid != euid() or info.st_nlink != 1
                                   or info.st_mode & 0o022):
            raise LayoutError(14, 'Audit log is not a private root-owned regular file.')
        _write_all(descriptor, line)
        os.fsync(descriptor)
    except OSError:
        raise LayoutError(14, 'Audit log write failed.') from None
    finally:
        os.close(descriptor)


def operator_identity():
    """Who runs this command: the sudo caller when present, else the real
    account (V3D-07)."""
    import pwd
    sudo = os.environ.get('SUDO_USER', '')
    try:
        real = pwd.getpwuid(os.getuid()).pw_name
    except KeyError:
        real = str(os.getuid())
    return (sudo if re.fullmatch(r'[a-z_][a-z0-9_.-]{0,31}', sudo or '') else real) + ('(sudo)' if sudo else '')


def txn_audit(txn, result, backup=None, **extra):
    """One audit line with the fields every transaction event carries
    (V3D-07): package identity, txn id, old/new build, operator."""
    fields = {'package': txn.get('package', '?'), 'package_manifest_sha256': txn.get('package_manifest_sha256', '-'),
              'txn': txn.get('txn_id', '?'),
              'from': (txn.get('old') or {}).get('version') or 'none',
              'from_build': ((txn.get('old') or {}).get('build') or 'none')[:12],
              'to': (txn.get('new') or {}).get('version', '?'),
              'to_build': ((txn.get('new') or {}).get('build') or '?')[:12],
              'operator': operator_identity(), 'result': result}
    if backup is not None:
        fields['backup'] = str(backup)
    fields.update(extra)
    audit(txn['data_dir'], txn['kind'], **fields)


def _rollback_audit_fields(txn):
    trigger = txn.get('rollback_trigger') or {}
    return {'mode': trigger.get('mode', 'manual'), 'trigger_stage': trigger.get('stage') or '-',
            'trigger_reason': (trigger.get('reason') or '-')[:300], 'started_by': trigger.get('operator') or '-'}


# ---------------------------------------------------------------- child process groups (V1001R-05 / S-01)
GATE_SH = ('i=0; while [ ! -e "$1" ]; do i=$((i+1)); [ "$i" -gt 600 ] && exit 99; sleep 0.1; done; '
           'shift; exec "$@"')


def boot_id():
    try:
        return Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    except OSError:
        return ''


def _proc_fields(pid):
    try:
        text = Path('/proc/%d/stat' % int(pid)).read_text()
    except (OSError, ValueError):
        return None
    return text.rsplit(')', 1)[1].split()


def proc_start(pid):
    fields = _proc_fields(pid)
    return fields[19] if fields and len(fields) > 19 else None


def group_members(pgid):
    members = []
    for entry in os.listdir('/proc') if os.path.isdir('/proc') else []:
        if entry.isdigit():
            fields = _proc_fields(entry)
            if fields and len(fields) > 2 and fields[2] == str(pgid) and fields[0] != 'Z':
                members.append(int(entry))
    return members


def register_child(backup, pid):
    txn = txn_load(backup)
    children = list(txn.get('children') or [])
    start = proc_start(pid)
    if start is None:
        raise LayoutError(15, 'The transaction child exited before it could be recorded.')
    children.append({'pgid': int(pid), 'boot_id': boot_id(), 'start': start})
    return txn_update(backup, children=children)


def _record_is_ours(record):
    """Generation check (V1001S-01 / T-03). Returns True (ours: same boot and
    the leader runs with the recorded start time), False (provably gone or
    another generation: never signalled) or None (leader gone but the group
    number has live members: their generation cannot be proven, so nothing is
    signalled and destructive steps are refused for manual handling)."""
    if not boot_id() or record.get('boot_id') != boot_id():
        return False
    pgid = int(record['pgid'])
    start = proc_start(pgid)
    if start is not None:
        return start == record.get('start')
    return None if group_members(pgid) else False


def finish_child(backup, pgid, wait=10):
    """Persistently drop a finished group from the transaction once no
    member is left (V1001S-01)."""
    deadline = time.monotonic() + wait
    while group_members(pgid) and time.monotonic() < deadline:
        time.sleep(0.1)
    if group_members(pgid):
        return False
    txn = txn_load(backup)
    children = [c for c in txn.get('children') or [] if int(c['pgid']) != int(pgid)]
    txn_update(backup, children=children)
    return True


def terminate_children(txn, backup=None):
    """Stop every process group of this transaction that provably still is
    ours; records that are not (or no longer) ours are dropped without any
    signal. Raises if one of ours survives TERM and KILL."""
    import signal
    survivors, kept, unproven = [], [], []
    for record in txn.get('children') or []:
        ours = _record_is_ours(record)
        if ours is None:
            unproven.append(record)
            kept.append(record)
            continue
        if not ours:
            continue
        pgid = int(record['pgid'])
        for sig, wait in ((signal.SIGTERM, 30), (signal.SIGKILL, 10)):
            if not group_members(pgid):
                break
            try:
                os.killpg(pgid, sig)
            except ProcessLookupError:
                break
            deadline = time.monotonic() + wait
            while group_members(pgid) and time.monotonic() < deadline:
                time.sleep(0.1)
        if group_members(pgid):
            survivors += group_members(pgid)
            kept.append(record)
    if backup is not None:
        txn_update(backup, children=kept)
    if unproven:
        raise LayoutError(17, 'Process group %s of this transaction lost its leader and still has members whose '
                          'origin cannot be proven; nothing was signalled. Check them manually (ps -o pid,pgid,'
                          'lstart,cmd -g <pgid>), stop them if they belong to the install/patch, then rerun.'
                          % ','.join(str(r['pgid']) for r in unproven))
    if survivors:
        raise LayoutError(15, 'Transaction child processes are still running (%s); destructive steps refused.'
                          % ','.join(map(str, survivors[:10])))


def run_registered(backup, name, command, env, timeout=600):
    """Start command in its own session behind a gate, record its process
    group in the transaction, then release the gate and wait; the record is
    removed once the group has completely exited."""
    gate = Path(backup) / ('gate-' + name + '-' + str(os.getpid()))
    process = subprocess.Popen(['/bin/sh', '-c', GATE_SH, 'gate', str(gate), *command], env=env,
                               start_new_session=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        register_child(backup, process.pid)
        descriptor = os.open(gate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        os.close(descriptor)
        stdout, stderr = process.communicate(timeout=timeout)
    except BaseException:
        import signal
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()
        raise
    finally:
        try:
            os.unlink(gate)
        except FileNotFoundError:
            pass
    finish_child(backup, process.pid)
    return subprocess.CompletedProcess(process.args, process.returncode, stdout, stderr)


def start_registered(backup, name, command, env, before_release=None):
    """Like run_registered, but returns the running Popen (check-port server).
    before_release(pgid) runs after the group is recorded and before the
    gate opens (the check-port token is bound to that group, V1001T-04)."""
    gate = Path(backup) / ('gate-' + name + '-' + str(os.getpid()))
    process = subprocess.Popen(['/bin/sh', '-c', GATE_SH, 'gate', str(gate), *command], env=env,
                               start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    register_child(backup, process.pid)
    if before_release is not None:
        before_release(process.pid)
    descriptor = os.open(gate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    os.close(descriptor)
    return process, gate


# ---------------------------------------------------------------- transactions
def journal_path(data_dir):
    return Path(data_dir) / JOURNAL_NAME


def _write_json(path, value, mode=0o600):
    write_private_atomic(path, json.dumps(value, indent=2, sort_keys=True) + '\n', mode)


def _load_trusted_json(path, label):
    value = json.loads(read_trusted_text(path, label))
    if not isinstance(value, dict):
        raise LayoutError(12, label + ' is not a JSON object.')
    return value


def systemctl_run(arguments, command=None, timeout=120):
    try:
        result = subprocess.run([*(command or systemctl_command()), *arguments], capture_output=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return 255, ''
    return result.returncode, result.stdout.decode('utf-8', 'replace').strip()


ENABLED_STATES = {'enabled', 'enabled-runtime', 'static', 'alias', 'indirect', 'generated', 'linked', 'linked-runtime'}
DISABLED_STATES = {'disabled', 'masked', 'masked-runtime'}


def service_state(service=SERVICE_NAME, command=None, unit_exists=True):
    """Tri-state query (V1001S-12): {'enabled': bool, 'active': bool}; an
    answer that is neither clearly on nor clearly off raises instead of
    being read as False. A missing unit file is clearly disabled/inactive."""
    if not unit_exists:
        return {'enabled': False, 'active': False, 'unit_file_state': 'absent'}
    _, enabled = systemctl_run(['is-enabled', service], command)
    _, active = systemctl_run(['is-active', service], command)
    if enabled in ENABLED_STATES:
        is_enabled = True
    elif enabled in DISABLED_STATES:
        is_enabled = False
    else:
        raise LayoutError(15, 'Cannot determine whether %s is enabled (answer %r); refused.' % (service, enabled))
    if active == 'active':
        is_active = True
    elif active in ('inactive', 'failed'):
        is_active = False
    else:
        raise LayoutError(15, 'Cannot determine whether %s is running (answer %r); refused.' % (service, active))
    return {'enabled': is_enabled, 'active': is_active, 'unit_file_state': enabled}


SUPPORTED_UNIT_FILE_STATES = ('enabled', 'disabled')


def service_state_for_txn(service=SERVICE_NAME, command=None, unit_exists=True):
    """State recorded at transaction start (V1001T-07): the exact
    UnitFileState string is kept; only 'enabled' and 'disabled' can be
    restored exactly (systemctl enable/disable), so any other state
    (enabled-runtime, linked, static, masked, ...) refuses the transaction."""
    state = service_state(service, command, unit_exists)
    if unit_exists and state['unit_file_state'] not in SUPPORTED_UNIT_FILE_STATES:
        raise LayoutError(15, 'The unit file state of %s is %r; this version restores only enabled/disabled. '
                          'Make it plainly enabled or disabled first; nothing was changed.'
                          % (service, state['unit_file_state']))
    return state


def stop_service_verified(service=SERVICE_NAME, command=None):
    """Stop must succeed and the unit must then be provably stopped
    (V1001-11 / V1001R-11): is-active must answer inactive/failed, MainPID
    must be 0 and the unit cgroup must hold no process. Any query failure or
    unknown answer refuses the destructive steps."""
    rc, _ = systemctl_run(['stop', service], command)
    if rc != 0:
        raise LayoutError(15, 'systemctl stop ' + service + ' failed (exit %d); destructive steps refused.' % rc)
    rc, state = systemctl_run(['is-active', service], command)
    if rc == 0 or state not in ('inactive', 'failed'):
        raise LayoutError(15, 'Service state after stop is "%s" (exit %d); destructive steps refused.' % (state, rc))
    rc, main_pid = systemctl_run(['show', '-p', 'MainPID', '--value', service], command)
    if rc != 0 or main_pid != '0':
        raise LayoutError(15, 'Cannot confirm that the service main process stopped (MainPID=%r, exit %d).'
                          % (main_pid, rc))
    rc, group = systemctl_run(['show', '-p', 'ControlGroup', '--value', service], command)
    if rc != 0:
        raise LayoutError(15, 'Cannot read the service control group; destructive steps refused.')
    if group:
        procs = Path('/sys/fs/cgroup') / group.lstrip('/') / 'cgroup.procs'
        try:
            remaining = procs.read_text().split()
        except FileNotFoundError:
            remaining = []
        except OSError:
            raise LayoutError(15, 'Cannot read the service control group; destructive steps refused.') from None
        if remaining:
            raise LayoutError(15, 'Processes remain in the service control group after stop: '
                              + ','.join(remaining[:10]))


def _write_recovery_runtimes(backup, txn):
    candidates = [txn.get('runtime_retained'), txn['runtime_dir']]
    text = ''.join(path + '\n' for path in candidates if path)
    write_private_atomic(Path(backup) / 'RECOVERY_RUNTIMES', text, 0o600)


def _file_meta(path):
    """Supported metadata contract (V1001S-10): owner, group and mode are
    saved and restored; SELinux labels are reset with restorecon; any other
    extended attribute (POSIX ACLs included) is refused before a change."""
    info = os.lstat(path)
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise LayoutError(12, str(path) + ' must be a regular file.')
    import errno
    try:
        names = os.listxattr(path, follow_symlinks=False) if hasattr(os, 'listxattr') else []
    except OSError as error:
        # V1001T-05: only "this filesystem has no xattr support" means none.
        if error.errno not in (errno.ENOTSUP, getattr(errno, 'EOPNOTSUPP', errno.ENOTSUP)):
            raise LayoutError(12, 'Cannot read the extended attributes of %s (%s); refused before any change.'
                              % (path, errno.errorcode.get(error.errno, error.errno))) from None
        names = []
    foreign = [n for n in names if n != 'security.selinux']
    if foreign:
        raise LayoutError(12, str(path) + ' carries extended attributes/ACLs (' + ', '.join(foreign[:3]) +
                          ') that the installer cannot restore; remove them first (setfacl -b) or ask for '
                          'manual handling. Nothing was changed.')
    return {'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid, 'gid': info.st_gid}


def selinux_relabel(paths):
    """Reset SELinux labels of restored files to the policy default."""
    if not os.path.exists('/sys/fs/selinux/enforce'):
        return 'selinux-off'
    tool = shutil.which('restorecon', path='/usr/sbin:/sbin:/usr/bin:/bin')
    if not tool:
        raise LayoutError(15, 'SELinux is enabled but restorecon is missing; labels of restored files cannot be reset.')
    result = subprocess.run([tool, *map(str, paths)], capture_output=True, timeout=120)
    if result.returncode:
        raise LayoutError(15, 'restorecon failed for the restored files.')
    return 'restorecon'


def txn_begin(data_dir, kind, record, *, conf_path, unit_path, marker_path, layout_source=None, tag=None,
              config_value=None, svc_gid=None, config_path=None):
    """Create the backup directory, copy state files (with owner/group/mode),
    snapshot the verified configuration, write txn.json and then the
    journal. Returns the backup path."""
    if kind not in ('patch', 'install'):
        raise LayoutError(13, 'Unknown transaction kind.')
    data_dir = Path(data_dir)
    check_trusted_dir(data_dir, 'DATA_DIR')
    if journal_path(data_dir).exists() or journal_path(data_dir).is_symlink():
        raise LayoutError(12, 'Another transaction journal is open; recover it first.')
    sources = (('conf', conf_path, 'install.conf'), ('unit', unit_path, SERVICE_NAME + '.service'),
               ('marker', marker_path, 'INSTALLATION.json'), ('config', config_path, 'config.json'))
    meta = {}
    for label, source, _ in sources:  # refuse unsupported metadata before any change
        if source is not None and os.path.lexists(source):
            meta[label] = _file_meta(source)
    digest = attachments_digest(record.get('attachments'))
    name = kind + '_backup_' + (tag or datetime.now().strftime('%Y%m%d%H%M%S') + '_' + str(os.getpid()))
    if not BACKUP_NAME_RE.fullmatch(name):
        raise LayoutError(13, 'Invalid backup directory name.')
    backup = data_dir / name
    for attempt in range(100):
        try:
            os.mkdir(backup, 0o700)
            break
        except FileExistsError:
            backup = data_dir / (name + str(attempt))
    else:
        raise LayoutError(12, 'Cannot create a unique backup directory.')
    ensure_directory(backup, 0o700)
    copies = {}
    for label, source, target in sources:
        if source is not None and os.path.lexists(source):
            if label == 'config':
                text = json.dumps(read_service_config(source), ensure_ascii=False, indent=2)
            else:
                text = read_trusted_text(source, target)
            write_private_atomic(backup / target, text, 0o600)
            copies[label] = True
        else:
            copies[label] = False
    if layout_source is not None:
        write_private_atomic(backup / 'layout.py', Path(layout_source).read_text(encoding='utf-8'), 0o600)
        write_private_atomic(backup / 'ROLLBACK_NOW.sh', ROLLBACK_SCRIPT, 0o700)
    txn_id = hashlib.sha256(os.urandom(32)).hexdigest()[:32]
    snapshot = None
    if config_value is not None:
        snapshot = write_config_snapshot(data_dir, txn_id, config_value, svc_gid)
    txn = {'format': TXN_FORMAT, 'txn_id': txn_id, 'kind': kind,
           'created': now_iso(), 'state': 'OPEN', 'phase': 'PREPARED', 'backup': str(backup),
           'data_dir': str(data_dir), 'conf_path': str(conf_path), 'unit_path': str(unit_path) if unit_path else None,
           'marker_path': str(marker_path), 'config_path': str(config_path) if config_path else None,
           'had_conf': copies['conf'], 'had_unit': copies['unit'], 'had_marker': copies['marker'],
           'had_config': copies['config'], 'file_meta': meta,
           'db_backup': None, 'db_backup_sha256': None, 'db_identity': None,
           'runtime_retained': None, 'release_retained': None, 'children': [], 'boot_id': boot_id(),
           'config_snapshot': snapshot,
           'config_sha256': config_sha256(config_value) if config_value is not None else None,
           'attachments_digest': digest, 'operator': operator_identity(), **record}
    _validate_txn(txn, backup)
    _write_json(backup / 'txn.json', txn)
    _write_recovery_runtimes(backup, txn)
    # 0644: the unit's ExecStartPre guard (service account) reads the txn id.
    _write_json(journal_path(data_dir), {'format': TXN_FORMAT, 'txn_id': txn['txn_id'], 'backup': str(backup),
                                         'app_dir': txn['app_dir']}, 0o644)
    return backup


def _validate_txn(txn, backup):
    if txn.get('format') != TXN_FORMAT or txn.get('kind') not in ('patch', 'install'):
        raise LayoutError(12, 'Transaction record format is invalid.')
    if txn.get('state') not in ('OPEN', 'COMMITTED', 'ROLLING_BACK', 'ROLLED_BACK'):
        raise LayoutError(12, 'Transaction state is invalid.')
    if Path(txn['backup']) != Path(backup) or Path(backup).parent != Path(txn['data_dir']) \
            or not BACKUP_NAME_RE.fullmatch(Path(backup).name):
        raise LayoutError(12, 'Transaction backup directory does not belong to this data directory.')
    for key in ('app_dir', 'runtime_dir', 'data_dir', 'conf_path', 'marker_path'):
        clean_absolute(txn[key], key, min_parts=2)
    previous = txn.get('prev_current')
    if previous is not None and not RELEASE_LINK_RE.fullmatch(previous):
        raise LayoutError(12, 'Recorded previous release link is invalid.')
    if not RELEASE_NAME_RE.fullmatch(txn['new']['release']):
        raise LayoutError(12, 'Recorded new release is invalid.')
    for key in ('db_backup', 'runtime_retained', 'release_retained', 'config_snapshot', 'config_path'):
        if txn.get(key) is not None:
            clean_absolute(txn[key], key, min_parts=2)
    if txn.get('config_path') and PurePosixPath(txn['config_path']).parent != PurePosixPath(txn['data_dir']):
        raise LayoutError(12, 'Recorded config.json is not directly inside DATA_DIR.')
    if txn.get('runtime_retained') and PurePosixPath(txn['runtime_retained']).parent != PurePosixPath(txn['runtime_dir']).parent:
        raise LayoutError(12, 'Recorded retained runtime is not next to RUNTIME_DIR.')
    if txn.get('release_retained') and PurePosixPath(txn['release_retained']).parent != PurePosixPath(txn['app_dir']) / 'releases':
        raise LayoutError(12, 'Recorded retained release is not in APP_DIR/releases.')
    if txn.get('db_backup') and not inside(txn['db_backup'], txn['data_dir']):
        raise LayoutError(12, 'Recorded database backup is outside DATA_DIR.')
    if txn.get('config_snapshot') and PurePosixPath(txn['config_snapshot']) != \
            PurePosixPath(txn['data_dir']) / snapshot_name(txn['txn_id']):
        raise LayoutError(12, 'Recorded configuration snapshot path is invalid.')


def txn_load(backup):
    backup = Path(backup)
    check_trusted_dir(backup, 'Backup directory')
    if euid() is not None and stat.S_IMODE(os.lstat(backup).st_mode) & 0o077:
        raise LayoutError(12, 'Backup directory must be private (0700).')
    txn = _load_trusted_json(backup / 'txn.json', 'txn.json')
    _validate_txn(txn, backup)
    return txn


def txn_update(backup, **fields):
    txn = txn_load(backup)
    txn.update(fields)
    _validate_txn(txn, backup)
    _write_json(Path(backup) / 'txn.json', txn)
    if 'runtime_retained' in fields:
        _write_recovery_runtimes(backup, txn)
    return txn


def _write_journal(txn):
    _write_json(journal_path(txn['data_dir']), {'format': TXN_FORMAT, 'txn_id': txn['txn_id'],
                                                 'backup': txn['backup'], 'app_dir': txn['app_dir']}, 0o644)


def _remove_journal(txn):
    try:
        os.unlink(journal_path(txn['data_dir']))
    except FileNotFoundError:
        pass
    fsync_dir(txn['data_dir'])


def open_journal(data_dir):
    """Return (journal dict, txn dict) for an open transaction, or None."""
    path = journal_path(data_dir)
    if not os.path.lexists(path):
        return None
    journal = _load_trusted_json(path, 'Transaction journal')
    backup = journal.get('backup')
    if journal.get('format') != TXN_FORMAT or not isinstance(backup, str) or Path(backup).parent != Path(data_dir) \
            or not BACKUP_NAME_RE.fullmatch(Path(backup).name):
        raise LayoutError(12, 'Transaction journal is invalid; inspect ' + str(path) + ' manually.')
    txn = txn_load(backup)
    if txn['txn_id'] != journal.get('txn_id'):
        raise LayoutError(12, 'Transaction journal does not match its backup record.')
    return journal, txn


def precommit(backup, owners=None):
    """Before the success audit: the live config must still equal the snapshot,
    the database must be the same file, attachments untouched; record the
    database hash that a later post-commit rollback compares against."""
    txn = txn_load(backup)
    terminate_children(txn, backup)
    conf = parse_conf(read_trusted_text(txn['conf_path'], 'install.conf'))
    if txn.get('config_sha256'):
        live = read_service_config(conf['CONFIG_FILE'], owners)
        if config_sha256(live) != txn['config_sha256']:
            raise LayoutError(13, 'config.json changed during the transaction; refusing to commit.')
    if txn.get('db_identity') and database_identity(txn['database']) != txn['db_identity']:
        raise LayoutError(13, 'The database file was replaced during the transaction; refusing to commit.')
    if not attachments_unchanged(txn.get('attachments'), txn['attachments_digest']):
        raise LayoutError(16, 'Attachments changed during the maintenance window; refusing to commit.')
    db_sha = database_sha256(txn['database']) if os.path.lexists(txn['database']) else None
    return txn_update(backup, phase='COMMITTING', committed_db_sha256=db_sha)


def txn_commit(backup):
    """Mark COMMITTED, then remove the journal (directory fsync). Crash in
    between is finished idempotently by recover_open_transaction()."""
    txn = txn_load(backup)
    current = open_journal(txn['data_dir'])
    if current is None or current[1]['txn_id'] != txn['txn_id']:
        raise LayoutError(12, 'Journal does not belong to this transaction.')
    txn = txn_update(backup, state='COMMITTED', phase='COMMITTED', committed=now_iso(), retire_pending=True)
    kill_point('commit_before_journal_remove')
    _remove_journal(txn)
    remove_config_snapshot(txn)
    kill_point('commit_before_retire')
    return finish_retire(backup)


def finish_retire(backup):
    """retire_pending (V1001V-01): mark the stale to-dos of OLDER backups
    superseded by this committed transaction, then clear the flag. Rerun
    safe: superseding is idempotent and the flag stays until it is done."""
    txn = txn_load(backup)
    if txn.get('retire_pending'):
        supersede_stale_todos(txn)
        txn = txn_update(backup, retire_pending=False)
    return txn


def supersede_stale_todos(txn):
    """V1001U-01: once a later transaction committed (same lock held), the
    "start the previous version" / "restart after a refused rollback" to-dos
    of OLDER backups no longer describe this installation: mark them
    superseded (durably, audited) so that recovery never selects them."""
    for candidate in sorted(Path(txn['data_dir']).glob('*_backup_*')):
        if candidate == Path(txn['backup']) or not BACKUP_NAME_RE.fullmatch(candidate.name) \
                or not (candidate / 'txn.json').is_file():
            continue
        try:
            old = txn_load(candidate)
        except (LayoutError, OSError, ValueError):
            continue
        if old.get('created', '') > txn.get('created', ''):
            continue  # only OLDER transactions are superseded by this one
        fields = {}
        if old.get('pending_start'):
            fields['pending_start'] = False
        if old.get('abort_restart_pending'):
            fields['abort_restart_pending'] = False
        if not fields:
            continue
        retire_todo(candidate, fields, txn['txn_id'])


def retire_todo(backup, fields, superseded_by):
    """V1001W-01: retire a to-do and owe its TODO_SUPERSEDED audit record in
    ONE durable write (audit_pending carries a unique event id), then write
    the record and clear audit_pending. A crash or an audit failure in
    between leaves audit_pending, which every recovery entry finishes; the
    event id keeps a replay from writing the record twice."""
    event = {'result': 'TODO_SUPERSEDED', 'event_id': secrets.token_hex(8), 'superseded_by': superseded_by,
             'flags': sorted(fields)}
    txn_update(backup, superseded_by=superseded_by, superseded_at=now_iso(), audit_pending=event, **fields)
    kill_point('retire_before_audit')
    try:
        flush_audit_pending(backup)
    except LayoutError as error:  # the retire itself is durable; the record is still owed
        print('WARNING: the TODO_SUPERSEDED record of %s is still owed (%s); rerun to finish it.' % (backup, error),
              file=sys.stderr)


def _audit_has_event(data_dir, kind, event_id):
    path = PurePosixPath(data_dir) / (kind + '_audit.log')
    try:
        descriptor = os.open(str(path), os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    except FileNotFoundError:
        return False
    except OSError:
        raise LayoutError(14, 'Cannot read the audit log ' + str(path)) from None
    with os.fdopen(descriptor, 'rb') as handle:
        needle = ('\tevent=' + event_id).encode()
        return any(line.rstrip(b'\n').endswith(needle) or (needle + b'\t') in line for line in handle)


def flush_audit_pending(backup):
    """Write the owed audit record of this backup once (deduplicated by event
    id), then clear audit_pending. Raises LayoutError while it cannot."""
    txn = txn_load(backup)
    event = txn.get('audit_pending')
    if not event:
        return txn
    if not _audit_has_event(txn['data_dir'], txn['kind'], event['event_id']):
        txn_audit(txn, event['result'], backup, superseded_by=event.get('superseded_by'),
                  todo=','.join(event.get('flags', [])), event=event['event_id'])
    kill_point('retire_after_audit')
    return txn_update(backup, audit_pending=None)


def lock_path(app_dir):
    app = PurePosixPath(app_dir)
    return app.parent / ('.' + app.name + '.install.lock')


def acquire_lock(app_dir, lock_fd=None):
    """Take the install/patch lock (shared with install.py and patch.sh).
    lock_fd: a descriptor inherited from the caller; it must be the lock file
    of this APP_DIR (same device and inode, V1001S-06). flock on the same open
    file description succeeds, so there is no self-deadlock."""
    import fcntl
    path = lock_path(app_dir)
    if lock_fd is not None:
        descriptor = lock_fd
        owned = False
        try:
            expected = os.lstat(str(path))
        except FileNotFoundError:
            raise LayoutError(12, 'The inherited lock does not belong to ' + str(app_dir) + '.') from None
        info = os.fstat(descriptor)
        if (info.st_dev, info.st_ino) != (expected.st_dev, expected.st_ino):
            raise LayoutError(12, 'The inherited lock does not belong to ' + str(app_dir) + '.')
    else:
        check_trusted_dir(path.parent, 'Lock directory')
        descriptor = os.open(str(path), os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
        owned = True
    info = os.fstat(descriptor)
    if not stat.S_ISREG(info.st_mode) or info.st_uid != euid() or info.st_nlink != 1 or info.st_mode & 0o022:
        raise LayoutError(12, 'Unsafe installer lock ownership, permissions or file type.')
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        if owned:
            os.close(descriptor)
        raise LayoutError(12, 'Another install/patch/rollback operation holds the lock.') from None
    return descriptor if owned else None


def _restore_file(source, target, present, meta, default_mode=0o644):
    """Atomically restore a root-managed file with its recorded owner,
    group and mode (V1001S-10), or remove a file that did not exist."""
    target = Path(target)
    if not present:
        try:
            os.unlink(target)
        except FileNotFoundError:
            pass
        fsync_dir(target.parent)
        return
    meta = meta or {'mode': default_mode, 'uid': None, 'gid': None}
    temporary = target.with_name('.' + target.name + '.restore-' + str(os.getpid()))
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        data = Path(source).read_bytes()
        _write_all(descriptor, data)
        if euid() == 0 and meta.get('uid') is not None:
            os.fchown(descriptor, meta['uid'], meta['gid'])
        if hasattr(os, 'fchmod'):
            os.fchmod(descriptor, meta['mode'])
        os.fsync(descriptor)
    except BaseException:
        os.close(descriptor)
        os.unlink(temporary)
        raise
    os.close(descriptor)
    os.replace(temporary, target)
    fsync_dir(target.parent)


def _switch_link(app_dir, target):
    app = Path(app_dir)
    pointer = app / ('.current-rollback-' + str(os.getpid()))
    if os.path.lexists(pointer):
        os.unlink(pointer)
    os.symlink(target, pointer)
    os.replace(pointer, app / 'current')
    fsync_dir(app)


# ---------------------------------------------------------------- start guard and check-port token
def create_run_token(txn_id, pid, check_pgid=None, config=None):
    """Check-port permission (V1001S-09 / T-04) bound to this transaction, the
    live installer/patch process (pid + start time + boot id), the process
    group already registered in the transaction for the check-port server,
    and the transaction's configuration snapshot."""
    path = run_token_path()
    start = proc_start(pid)
    if start is None:
        raise LayoutError(15, 'The process the token should belong to is not running.')
    value = {'txn_id': txn_id, 'pid': int(pid), 'start': start, 'boot_id': boot_id()}
    if check_pgid is not None:
        group_start = proc_start(check_pgid)
        if group_start is None:
            raise LayoutError(15, 'The check-port process group is not running.')
        value.update(check_pgid=int(check_pgid), check_start=group_start, config=str(config))
    value = json.dumps(value)
    temporary = path + '.tmp-' + str(os.getpid())
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, 'O_NOFOLLOW', 0), 0o644)
    with os.fdopen(descriptor, 'w') as stream:
        if hasattr(os, 'fchmod'):
            os.fchmod(stream.fileno(), 0o644)
        stream.write(value)
    os.replace(temporary, path)


def remove_run_token():
    try:
        os.unlink(run_token_path())
    except FileNotFoundError:
        pass


def start_guard(data_dir, token_path=None):
    """ExecStartPre (service account): the real service never starts while a
    transaction journal is open; rollbacks start the previous version only
    after the journal is closed (V1001S-03)."""
    if os.path.lexists(Path(data_dir) / JOURNAL_NAME):
        return False, 'unfinished install/patch transaction; rerun patch.sh or INSTALL.sh to recover'
    if quarantined(data_dir):
        return False, ('rolled back with --accept-data-loss; closed until an operator approves '
                       '(INSTALL.sh --production --approve-rollback)')
    return True, 'no open transaction'


def check_port_authorized(data_dir, token_path, config=None):
    """--check-port is allowed only with a token of the open transaction
    whose creating installer/patch process is still alive (V1001S-09), and
    only for the process group registered for it, started with the
    transaction's configuration snapshot (V1001T-04)."""
    journal = Path(data_dir) / JOURNAL_NAME
    try:
        txn_id = json.loads(journal.read_text(encoding='utf-8'))['txn_id']
        token = json.loads(Path(token_path).read_text(encoding='utf-8'))
    except (OSError, ValueError, KeyError, TypeError):
        return False, 'no open transaction or no check-port token'
    if not isinstance(token, dict) or token.get('txn_id') != txn_id or token.get('boot_id') != boot_id():
        return False, 'the check-port token does not belong to the open transaction'
    if proc_start(token.get('pid', 0)) is None or proc_start(token['pid']) != token.get('start'):
        return False, 'the installer that created the check-port token is no longer running'
    if config is not None:
        group = token.get('check_pgid')
        if group is None or os.getpgrp() != group or proc_start(group) != token.get('check_start'):
            return False, 'this process is not the check-port process group registered in the transaction'
        if os.path.abspath(str(config)) != token.get('config'):
            return False, 'the check port must use the configuration snapshot of the transaction'
    return True, 'installer verification'


# ---------------------------------------------------------------- rollback
def _current_and_conf(txn):
    link = Path(txn['app_dir']) / 'current'
    current = os.readlink(link) if os.path.islink(link) else None
    return current, read_conf_if_present(txn['conf_path'])


def _check_committed_rollback(txn, accept_data_loss):
    current, conf = _current_and_conf(txn)
    if current != 'releases/' + txn['new']['release'] or not conf or conf['VERSION'] != txn['new']['version'] \
            or conf['BUILD'] != txn['new']['build']:
        raise LayoutError(12, 'The installed version is no longer the one this backup upgraded to; '
                          'rolling back would overwrite a later change. Refused.')
    _check_database_unchanged(txn, accept_data_loss)


def _check_database_unchanged(txn, accept_data_loss):
    changed = _database_changed(txn)
    if changed and not accept_data_loss:
        raise LayoutError(12, 'The database changed after this upgrade committed (users wrote data). '
                          'Rerun with --accept-data-loss to restore the pre-change database copy anyway.')


def _database_changed(txn):
    return txn.get('committed_db_sha256') is None or \
        (os.path.lexists(txn['database']) and database_sha256(txn['database']) != txn['committed_db_sha256'])


QUARANTINE_NAME = 'ROLLBACK_QUARANTINED'


def _unrecoverable_data_change(txn):
    """V4C-04 / V4D-01: a committed rollback whose previous state has no
    v1.001 release (the takeover of v1.000.0, or a first install that took
    over an existing database) cannot carry the current access ledger
    (revocations, cleanups, issued numbers) into the restored copy: there is
    no previous product code for secure_rollback.py. If users wrote data after
    the commit such a rollback is refused -- --accept-data-loss never
    overrides this. Returns the refusal text or None."""
    if not (txn.get('adopt') or (txn.get('db_backup') and not txn.get('prev_current'))):
        return None
    if not _database_changed(txn):
        return None
    if txn.get('adopt'):
        return ('Users wrote data after the takeover of v1.000.0; returning to v1.000.0 would lose that data and '
                'could revive revoked access. Refused (also with --accept-data-loss); restore from a paired backup '
                'instead (README_PRODUCTION.md).')
    return ('Users wrote data after this first installation; the state before it has no v1.001 release that could '
            'carry the current revocations over. Refused (also with --accept-data-loss); restore from a paired '
            'backup instead (README_PRODUCTION.md).')


def _svc_tool(txn, release, args):
    """Command + environment for tools/secure_rollback.py of RELEASE, run as
    the service account with the installation's runtime (V3D-01)."""
    import pwd
    release = Path(release)
    command = [str(Path(txn['runtime_dir']) / 'bin/python3'), '-I', '-B', str(release / 'tools/secure_rollback.py'),
               *args, '--release', str(release)]
    if euid() == 0:
        command = ['/usr/sbin/runuser', '-u', pwd.getpwuid(txn['svc_uid']).pw_name, '--', *command]
    return command, {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LD_LIBRARY_PATH': str(release / 'vendor/lib')}


def _svc_tool_run(backup, txn, release, args, label):
    if not (Path(release) / 'tools/secure_rollback.py').is_file():
        raise LayoutError(13, 'Release %s has no tools/secure_rollback.py; the current access cannot be carried over, '
                          'so the database is not overwritten. Use the paired-backup restore instead.' % release)
    command, env = _svc_tool(txn, release, args)
    result = run_registered(backup, label, command, env, timeout=600)
    if result.returncode != 0:
        raise LayoutError(13, '%s failed (exit %d): %s' % (label, result.returncode,
                                                          result.stderr.decode('utf-8', 'replace')[-400:]))
    return result.stdout.decode('utf-8')


def _capture_current_ledger(backup, txn):
    """V3D-01: BEFORE the committed database is overwritten (service stopped),
    the CURRENT authorization/cleanup ledger and counters are read with the
    new release's product code and kept in the backup directory."""
    if txn.get('current_ledger_sha256'):
        return txn  # captured on an earlier attempt, before anything was overwritten
    release = Path(txn['app_dir']) / 'releases' / txn['new']['release']
    text = _svc_tool_run(backup, txn, release, ['capture', '--database', txn['database']], 'ledger-capture')
    json.loads(text)  # must be one JSON document
    write_private_atomic(Path(backup) / 'current-ledger.json', text, 0o600)
    return txn_update(backup, secure_restore=True, current_ledger_sha256=hashlib.sha256(text.encode()).hexdigest())


def _apply_current_ledger(backup, txn):
    """After the snapshot is back: apply the captured ledger with the restored
    (previous) release's product code; the copy stays RESTORE_BLOCKED."""
    import pwd
    text = read_trusted_text(Path(backup) / 'current-ledger.json', 'current-ledger.json', limit=LEDGER_LIMIT)
    if hashlib.sha256(text.encode()).hexdigest() != txn['current_ledger_sha256']:
        raise LayoutError(13, 'The captured current ledger differs from its record; refused.')
    # Handed to the service account inside ITS database directory: created
    # O_EXCL|O_NOFOLLOW and chowned through the descriptor (never by path).
    handoff = Path(txn['database']).parent / ('.rollback-ledger-' + txn['txn_id'] + '-' + str(os.getpid()) + '.json')
    descriptor = os.open(str(handoff), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        if euid() == 0:
            os.fchown(descriptor, txn['svc_uid'], txn['svc_gid'])
        _write_all(descriptor, text.encode('utf-8'))
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    try:
        release = Path(txn['app_dir']) / txn['prev_current']
        _svc_tool_run(backup, txn, release, ['apply', '--database', txn['database'], '--ledger', str(handoff)],
                      'ledger-apply')
    finally:
        try:
            os.unlink(handoff)
        except FileNotFoundError:
            pass


# J4 (release-prep2 D-02, 2026-11-26): a committed rollback with
# --accept-data-loss carries the CURRENT cleanup ledger into the previous
# release, whose own backup.apply_access_ledger refuses (409) a resource_type
# its retention.TARGETS does not list -- AFTER the database was already
# overwritten. Second-version types (label, time_entry, time_adjustment) are
# unknown to v1.001.0 (cleaning, deferring or resuming such a record creates
# one). The types the previous release accepts are read from ITS OWN
# retention.py, statically (ast; never imported or executed), and an unknown
# type refuses the rollback BEFORE any overwrite.
CLEANUP_TARGETS_FILE = 'app/src/workboard/retention.py'
# One size limit for the captured ledger, checked before the overwrite and used
# again when it is applied (release-prep3 C-02 / D-01; recovery.py signs records
# up to 50 MiB, the ledger itself is larger than any single record).
LEDGER_LIMIT = 256 << 20
_TARGETS_MUTATORS = {'update', 'pop', 'popitem', 'clear', 'setdefault', '__setitem__', '__delitem__'}


def release_cleanup_types(release):
    """Keys of TARGETS in RELEASE's workboard/retention.py: exactly one module-level
    literal table (string keys) and no other assignment or mutation anywhere."""
    path = Path(release) / CLEANUP_TARGETS_FILE
    try:
        tree = ast.parse(read_trusted_text(str(path), 'retention.py of the previous release'))
    except (LayoutError, OSError, UnicodeDecodeError, SyntaxError, ValueError) as error:
        raise LayoutError(12, 'The cleanup record types of the previous release cannot be read (%s: %s); '
                          'refused before any overwrite.' % (path, error)) from None
    found = None
    literal = None
    own = set()
    for node in tree.body:
        value = None
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) \
                and node.targets[0].id == 'TARGETS':
            value = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == 'TARGETS':
            value = node.value
        if value is not None:
            own.update({id(node), id(getattr(node, 'target', None) or node.targets[0])})
            literal = node if literal is None else False
            if literal and isinstance(value, ast.Dict) and value.keys and \
                    all(isinstance(k, ast.Constant) and isinstance(k.value, str) for k in value.keys):
                found = {k.value for k in value.keys}
    changed = False
    for node in ast.walk(tree):
        if id(node) in own and literal:
            continue
        if isinstance(node, ast.Name) and node.id == 'TARGETS' and isinstance(node.ctx, (ast.Store, ast.Del)):
            changed = True  # a second binding (also in a block, tuple unpacking, global in a function)
        elif isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == 'TARGETS' \
                and isinstance(node.ctx, (ast.Store, ast.Del)):
            changed = True
        elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == 'TARGETS' \
                and node.attr in _TARGETS_MUTATORS:
            changed = True
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name) and node.target.id == 'TARGETS':
            changed = True
    if not literal or not found or changed:
        raise LayoutError(12, 'The previous release does not declare its cleanup record types as one unchanged '
                          'literal TARGETS table (%s); refused before any overwrite.' % path)
    return found


def check_ledger_types(backup, txn):
    """Refuse (before the overwrite) when the captured ledger is unreadable for the
    apply step, or has cleanup records of a type the previous release's own
    restore code cannot apply. Code 13 = the capture differs from its record."""
    text = read_trusted_text(Path(backup) / 'current-ledger.json', 'current-ledger.json', limit=LEDGER_LIMIT)
    if hashlib.sha256(text.encode()).hexdigest() != txn.get('current_ledger_sha256'):
        raise LayoutError(13, 'The captured current ledger differs from its record; refused.')
    try:
        ledger = json.loads(text)
    except ValueError:
        raise LayoutError(12, 'The captured current ledger is not valid JSON; refused before any overwrite.') from None
    if not isinstance(ledger, dict):
        raise LayoutError(12, 'The captured current ledger has an unexpected format; refused before any overwrite.')
    items = ledger.get('cleanup_items')
    if items is None:
        return
    if not isinstance(items, list):
        raise LayoutError(12, 'The captured cleanup ledger has an unexpected format; refused before any overwrite.')
    if not items:
        return
    counts = {}
    for item in items:
        kind = item.get('resource_type') if isinstance(item, dict) else None
        key = kind if isinstance(kind, str) and kind else '<invalid record>'
        counts[key] = counts.get(key, 0) + 1
    known = release_cleanup_types(Path(txn['app_dir']) / txn['prev_current'])
    unknown = sorted(kind for kind in counts if kind == '<invalid record>' or kind not in known)
    if unknown:
        listed = ', '.join('%s x%d' % (kind, counts[kind]) for kind in unknown)
        raise LayoutError(12, 'The current cleanup records include types the previous version %s cannot restore '
                          '(%s): records of second-version data were cleaned, deferred or resumed. Its restore '
                          'would stop half-way after the database was overwritten. Refused before any overwrite. '
                          'An automatic return to %s that keeps the current revocations is not possible: keep the '
                          'current version (a paired backup of the current version restores within it), or follow '
                          '"從 v1.001.0 升到第二版" in README_PRODUCTION.md for the manual return.'
                          % (_old_version(txn), listed, _old_version(txn)))


def _old_version(txn):
    return (txn.get('old') or {}).get('version') or '?'


# J6 (release-prep2 D-03): second-version systemd units that the previous release
# ships no tool for (it could neither run nor remove them). A rollback the
# operator asked for (not the automatic one after a failed start) is refused until
# they are disabled with the CURRENT package.
LATER_UNITS = (('tools/auto_backup.py', ('projectapp-backup.timer', 'projectapp-backup.service'), (),
                '--auto-backup disable', 'timers.target.wants'),
               ('tools/extract_sandbox.py', ('projectapp-extract.socket', 'projectapp-extract@.service'),
                ('extract_sandbox.json',), '--extract-sandbox disable', 'sockets.target.wants'))


def _regular_file(path):
    try:
        return stat.S_ISREG(os.lstat(path).st_mode)
    except OSError:
        return False


def later_unit_problems(txn):
    """[(path, disable command)] left by features the previous release lacks."""
    if not (txn.get('systemd') and txn.get('unit_path') and txn.get('prev_current')):
        return []
    if (txn.get('rollback_trigger') or {}).get('mode') == 'automatic':
        return []  # the installer's own rollback after a failed start: never block it here
    previous = Path(txn['app_dir']) / txn['prev_current']
    unit_dir = Path(txn['unit_path']).parent
    data = txn['data_dir']
    where = '' if data == DEFAULT_DATA else ' --data-dir ' + shlex.quote(data)
    problems = []
    for tool, units, switches, option, wants in LATER_UNITS:
        if _regular_file(previous / tool):
            continue
        command = 'sudo bash <current %s package>/INSTALL.sh --production%s %s' % (
            (txn.get('new') or {}).get('version') or 'version', where, option)
        paths = [unit_dir / unit for unit in units] + [unit_dir / wants / unit for unit in units] + \
            [Path(data) / name for name in switches]
        problems += [(str(path), command) for path in paths if os.path.lexists(path)]
    return problems


def check_later_units(txn):
    problems = later_unit_problems(txn)
    if problems:
        commands = sorted({command for _, command in problems})
        raise LayoutError(12, 'Features of the current version that the previous version %s does not have are still '
                          'installed (%s). Refused before any overwrite: first run %s, then rerun this rollback.'
                          % (_old_version(txn), ', '.join(path for path, _ in problems), ' and '.join(commands)))


def quarantined(data_dir):
    return os.path.lexists(Path(data_dir) / QUARANTINE_NAME)


def _check_resume_consistent(txn):
    """V1001S-07: an interrupted rollback may only continue while the
    installation is still at this transaction's new or previous state."""
    current, conf = _current_and_conf(txn)
    allowed_links = {'releases/' + txn['new']['release'], txn.get('prev_current')}
    allowed_versions = {(txn['new']['version'], txn['new']['build'])}
    if txn.get('old'):
        allowed_versions.add((txn['old']['version'], txn['old'].get('build')))
    if current not in allowed_links | {None} or (conf and (conf['VERSION'], conf['BUILD']) not in allowed_versions):
        raise LayoutError(12, 'The installation moved on since this rollback started (current=%s); continuing it '
                          'would overwrite a later change. Refused.' % current)


def _check_attachments(txn):
    if txn.get('attachments_digest') is not None and \
            not attachments_unchanged(txn.get('attachments'), txn['attachments_digest']):
        raise LayoutError(16, 'Attachments were added, removed or changed (content SHA-256) since the transaction started; an automatic '
                          'rollback would leave database rows and files inconsistent. Refused: restore '
                          'manually from a paired backup (README_PRODUCTION.md, ROLLBACK.md).')


def rollback(backup, *, lock_fd=None, accept_data_loss=False, command=None, health_seconds=60, log=None,
             trigger=None):
    """Restore the state recorded in BACKUP/txn.json. Shared by the automatic
    path (patch.sh / installer), recovery on rerun, ROLLBACK_NOW.sh and
    INSTALL.sh --recover.

    Refusals (nothing touched) raise LayoutError. Otherwise the rollback is
    journaled (journal first, then state ROLLING_BACK) and resumable. The
    terminal state ROLLED_BACK (with its audit record) is persisted and the
    journal closed BEFORE the previous version is started again (V1001S-03).
    Statuses: ROLLED_BACK; ROLLED_BACK_START_FAILED (restored, but the old
    version did not come up: manual); ROLLED_BACK_AUDIT_PENDING;
    ROLLBACK_INCOMPLETE (journal kept, service refuses to start).
    trigger (V3D-07): {'mode': manual|automatic|recovery, 'stage', 'reason'}
    stored with the operator when the rollback starts (kept on resume).
    """
    trigger = dict(trigger or {'mode': 'manual'})
    trigger.update(operator=operator_identity(), at=now_iso())
    located = txn_load(backup)  # only to find the lock (V3C-02)
    owned_lock = acquire_lock(located['app_dir'], lock_fd)
    try:
        # V3C-02: every decision uses the state read UNDER the lock; another
        # rollback may have finished between the first read and the lock.
        txn = txn_load(backup)
        if txn['app_dir'] != located['app_dir'] or txn['txn_id'] != located['txn_id']:
            raise LayoutError(12, 'The transaction record changed while waiting for the lock; rerun.')
        journal = open_journal(txn['data_dir'])
        if journal is not None and journal[1]['txn_id'] != txn['txn_id']:
            raise LayoutError(12, 'Another transaction is open; this backup does not belong to it.')
        state = txn['state']
        if state == 'COMMITTED' and txn.get('retire_pending'):
            if journal is not None:
                _remove_journal(txn)
                journal = None
            txn = finish_retire(backup)
        if txn.get('audit_pending'):  # V1001W-01: an owed TODO_SUPERSEDED record of this backup
            try:
                txn = flush_audit_pending(backup)
            except LayoutError as error:
                print('WARNING: the owed audit record of %s could not be written yet: %s' % (backup, error),
                      file=sys.stderr)
        if state == 'ROLLED_BACK':
            # V1001R-09 / T-06: finish the cleanup and the pending start only;
            # the data are never restored a second time.
            if journal is None and not txn.get('pending_start'):
                if txn.get('quarantine_pending') or txn.get('approval_pending'):
                    raise LayoutError(27, 'This rollback is done and waits for operator approval (or an approval '
                                      'was interrupted): INSTALL.sh --production --approve-rollback --backup '
                                      + str(backup))
                raise LayoutError(12, 'This transaction was already rolled back.')
            if journal is not None:
                _remove_journal(txn)
                remove_config_snapshot(txn)
            result = {'status': 'ROLLED_BACK_QUARANTINED' if txn.get('quarantine_pending') else 'ROLLED_BACK',
                      'finalized_only': True, 'backup': str(backup), 'steps': []}
            if txn.get('pending_start'):
                result = _finish_pending_start(backup, txn, command, health_seconds, result)
            return result
        if state == 'COMMITTED' and txn.get('abort_restart_pending'):
            # U-03: a refused rollback still owes the restart of the current
            # version; only that is retried, never a restore.
            problem = _restart_current(Path(backup), txn, command, health_seconds)
            reason = txn.get('rollback_refused') or 'the data changed'
            if problem:
                raise LayoutError(26, 'An earlier rollback was refused (' + reason + '); restarting the '
                                  'current version FAILED again: ' + problem)
            raise LayoutError(12, 'An earlier rollback was refused (' + reason + '); the current version '
                              'is running again and healthy. Nothing was overwritten.')
        if state == 'COMMITTED':
            if journal is not None:
                _remove_journal(txn)
            refusal = _unrecoverable_data_change(txn)
            if refusal:
                # U73: early refusal (nothing touched); repeated after the stop (V4C-04).
                raise LayoutError(12, refusal + ' Nothing was changed.')
            _check_committed_rollback(txn, accept_data_loss)
            _check_attachments(txn)
            check_later_units({**txn, 'rollback_trigger': trigger})  # J6, before the stop
            # V1001S-07: publish the global intent first, then the state.
            _write_journal(txn)
            kill_point('rollback_after_journal')
            txn = txn_update(backup, state='ROLLING_BACK', phase='ROLLBACK_STARTED', rollback_after_commit=True,
                             rollback_accept_data_loss=bool(accept_data_loss), rollback_trigger=trigger)
        elif state == 'OPEN':
            if journal is None:
                raise LayoutError(12, 'The transaction is open but its journal is missing; inspect manually.')
            _check_attachments(txn)
            txn = txn_update(backup, state='ROLLING_BACK', phase='ROLLBACK_STARTED', rollback_trigger=trigger)
        else:  # ROLLING_BACK: resume, but only while nothing moved on
            _check_resume_consistent(txn)
            txn = txn_update(backup, rollback_resumed=(txn.get('rollback_resumed') or [])[-9:] + [trigger])
            if journal is None:
                _write_journal(txn)
        return _rollback_steps(Path(backup), txn, command, health_seconds, accept_data_loss)
    finally:
        if owned_lock is not None:
            os.close(owned_lock)


def _abort_committed_rollback(backup, txn, command, reason, health_seconds=60, code=12):
    """V1001S-02 / U-03: after the stop the committed data turned out to have
    changed: give up before any overwrite and put the CURRENT (new) version
    back. The restart is a durable to-do written before the journal closes;
    success is claimed only after start + version/build health check."""
    needs_restart = bool(txn.get('systemd') and txn.get('unit_path') and os.path.exists(txn['unit_path']))
    txn = txn_update(backup, state='COMMITTED', phase='COMMITTED', rollback_refused=reason,
                     abort_restart_pending=needs_restart)
    kill_point('abort_before_journal_remove')
    _remove_journal(txn)
    kill_point('abort_after_journal_remove')
    problem = _restart_current(backup, txn, command, health_seconds) if needs_restart else None
    if problem:
        raise LayoutError(26, reason + ' Nothing was overwritten, but restarting the current version FAILED: '
                          + problem + ' Fix the cause and rerun the same command (it only retries the restart).')
    raise LayoutError(code, reason + ' Nothing was overwritten; the current version is running again and healthy.')


def _restart_current(backup, txn, command, health_seconds):
    """Start the committed (new) version and verify version/build/mode.
    Returns None on success, else a description; the to-do is cleared only
    on success. A leftover journal of this transaction is removed first (the
    unit refuses to start while any journal exists)."""
    found = open_journal(txn['data_dir'])
    if found is not None:
        if found[1]['txn_id'] != txn['txn_id']:
            return 'another transaction is open; finish it first'
        _remove_journal(txn)
    current, conf = _current_and_conf(txn)
    if current != 'releases/' + txn['new']['release'] or not conf or conf['VERSION'] != txn['new']['version'] \
            or conf['BUILD'] != txn['new']['build']:
        retire_todo(backup, {'abort_restart_pending': False}, 'installation changed')
        return None  # the restart no longer describes this installation
    service = txn.get('service') or SERVICE_NAME
    rc, _ = systemctl_run(['start', service], command)
    problem = None
    if rc != 0:
        problem = 'systemctl start returned %d' % rc
    else:
        conf = parse_conf(read_trusted_text(txn['conf_path'], 'install.conf'))
        ok, seen = wait_health(conf['BIND'], conf['API_PORT'], public_host(conf['CONFIG_FILE']),
                               txn['new']['version'], health_seconds, txn['new']['build'])
        if not ok:
            problem = 'the health check did not report %s (saw %s)' % (txn['new']['version'],
                                                                     (seen or {}).get('release_version'))
    if problem is None:
        txn_update(backup, abort_restart_pending=False)
    else:
        txn_update(backup, abort_restart_problem=problem)
    return problem


def _rollback_steps(backup, txn, command, health_seconds, accept_data_loss=False):
    data_dir = txn['data_dir']
    steps = []
    uses_systemd = bool(txn.get('systemd'))
    unit_path = txn.get('unit_path')
    service = txn.get('service') or SERVICE_NAME
    meta = txn.get('file_meta') or {}
    if txn['phase'] != 'ROLLBACK_DONE':
        try:
            remove_run_token()
            # 1. nothing of the transaction may still run (V1001R-05) and the
            #    service must really be stopped before files are swapped.
            terminate_children(txn, backup)
            steps.append('children:OK')
            if uses_systemd and unit_path and os.path.exists(unit_path):
                stop_service_verified(service, command)
                steps.append('stop:OK')
            if not txn.get('restore_started'):
                # 1b. V3C-03: never overwrite a database that a process outside
                #     the unit still serves or holds open; from here on nothing
                #     can write it any more (V4C-04: the checks below run on the
                #     quiesced data, not on a state read before the stop).
                if txn.get('db_backup'):
                    conf = read_conf_if_present(txn['conf_path']) or {}
                    ensure_quiesced(conf.get('BIND'), conf.get('API_PORT'), txn['database'], service)
                # 1c. V1001S-02 / T-01: on EVERY run that has not started restoring
                # yet (also a resumed one), re-check after the successful stop.
                # Consent is the current call's; the takeover / first-install
                # rule (V4C-04) is not subject to --accept-data-loss.
                if txn.get('rollback_after_commit'):
                    try:
                        refusal = _unrecoverable_data_change(txn)
                        if refusal:
                            raise LayoutError(12, refusal)
                        _check_database_unchanged(txn, accept_data_loss)
                        _check_attachments(txn)
                        check_later_units(txn)  # J6
                    except LayoutError as error:
                        _abort_committed_rollback(backup, txn, command, str(error), health_seconds)
                else:
                    _check_attachments(txn)
                # V3D-01: users wrote data after the commit and the operator accepted
                # losing it -- but never the revocations, cleanups and issued numbers.
                # (Without a previous release the change was refused just above.)
                if txn.get('rollback_after_commit') and txn.get('db_backup') and _database_changed(txn):
                    try:
                        txn = _capture_current_ledger(backup, txn)
                        check_ledger_types(backup, txn)  # J4: still nothing overwritten
                    except (LayoutError, ValueError, OSError, subprocess.SubprocessError, KeyError, TypeError) as error:
                        integrity = isinstance(error, LayoutError) and error.code == 13
                        reason = str(error) if isinstance(error, LayoutError) else \
                            'Capturing the current ledger failed (%s: %s)' % (type(error).__name__, str(error)[:200])
                        if not integrity:
                            # The capture must not be reused by a later attempt: it would
                            # miss revocations/cleanups made after this refusal. A capture
                            # that differs from its record (code 13) is kept for inspection.
                            # 2.000.30: a failing cleanup must never skip the restart of the
                            # current version (the service is stopped at this point).
                            try:
                                txn = txn_update(backup, secure_restore=False, current_ledger_sha256=None)
                            except (OSError, ValueError, LayoutError) as cleanup:
                                reason += ' (Clearing the capture record also failed: %s: %s)' % (
                                    type(cleanup).__name__, str(cleanup)[:200])
                            try:
                                os.unlink(Path(backup) / 'current-ledger.json')
                                fsync_dir(backup)
                            except FileNotFoundError:
                                pass
                            except OSError as cleanup:
                                reason += (' (Removing the captured ledger failed: %s: %s; delete %s before '
                                           'retrying.)' % (type(cleanup).__name__, str(cleanup)[:200],
                                                           Path(backup) / 'current-ledger.json'))
                        _abort_committed_rollback(backup, txn, command, reason, health_seconds, code=13 if integrity else 12)
            txn = txn_update(backup, phase='ROLLBACK_RESTORING', restore_started=True)
            # 2. current link.
            app = Path(txn['app_dir'])
            if txn.get('prev_current'):
                _switch_link(app, txn['prev_current'])
            elif os.path.islink(app / 'current') and os.readlink(app / 'current') == 'releases/' + txn['new']['release']:
                os.unlink(app / 'current')
                fsync_dir(app)
            steps.append('current:OK')
            kill_point('rollback_after_current')
            # 3. a repaired release directory (same-version repair).
            retained = txn.get('release_retained')
            if retained and os.path.lexists(retained):
                release = app / 'releases' / txn['new']['release']
                if os.path.lexists(release):
                    os.rename(release, str(release) + '.failed-' + txn['txn_id'][:8] + '-' + str(os.getpid()))
                os.rename(retained, release)
                fsync_dir(release.parent)
                steps.append('release:OK')
            # 4. runtime (full package only).
            retained = txn.get('runtime_retained')
            if retained and os.path.lexists(retained):
                runtime = Path(txn['runtime_dir'])
                if os.path.lexists(runtime):
                    os.rename(runtime, str(runtime) + '.failed-' + txn['txn_id'][:8] + '-' + str(os.getpid()))
                os.rename(retained, runtime)
                fsync_dir(runtime.parent)
                steps.append('runtime:OK')
            # 5. database.
            if txn.get('db_backup'):
                if sha256(txn['db_backup']) != txn['db_backup_sha256']:
                    raise LayoutError(13, 'Database backup checksum differs from the transaction record.')
                sqlite_restore(txn['db_backup'], txn['database'], txn.get('svc_uid'), txn.get('svc_gid'),
                               txn['db_backup_sha256'])
                steps.append('database:OK')
                if txn.get('secure_restore'):
                    _apply_current_ledger(backup, txn)
                    steps.append('current_access:OK')
            # 6. install.conf, INSTALLATION.json, config.json (V1001S-04), unit + enabled state.
            restored = []
            _restore_file(backup / 'install.conf', txn['conf_path'], txn['had_conf'], meta.get('conf'))
            _restore_file(backup / 'INSTALLATION.json', txn['marker_path'], txn['had_marker'], meta.get('marker'))
            restored += [p for p, had in ((txn['conf_path'], txn['had_conf']), (txn['marker_path'], txn['had_marker'])) if had]
            if txn.get('config_path') and txn.get('had_config'):
                _restore_file(backup / 'config.json', txn['config_path'], True, meta.get('config'), 0o600)
                restored.append(txn['config_path'])
                if txn.get('config_sha256') and config_sha256(read_service_config(txn['config_path'])) != txn['config_sha256']:
                    raise LayoutError(13, 'Restored config.json differs from the transaction snapshot.')
            steps.append('install_conf:OK')
            if uses_systemd and unit_path:
                if not txn['had_unit'] and os.path.exists(unit_path):
                    rc, _ = systemctl_run(['disable', service], command)
                    if rc != 0:
                        raise LayoutError(15, 'systemctl disable failed while removing the new unit.')
                _restore_file(backup / (SERVICE_NAME + '.service'), unit_path, txn['had_unit'], meta.get('unit'))
                if txn['had_unit']:
                    restored.append(unit_path)
                rc, _ = systemctl_run(['daemon-reload'], command)
                if rc != 0:
                    raise LayoutError(15, 'systemctl daemon-reload failed during rollback.')
                if txn['had_unit']:
                    wanted = txn.get('service_unit_state') or ('enabled' if txn.get('service_enabled') else 'disabled')
                    if wanted not in SUPPORTED_UNIT_FILE_STATES:
                        raise LayoutError(15, 'Recorded unit file state %r cannot be restored exactly.' % wanted)
                    rc, _ = systemctl_run(['enable' if wanted == 'enabled' else 'disable', service], command)
                    if rc != 0:
                        raise LayoutError(15, 'Restoring the unit enabled state failed.')
                    now = service_state(service, command)['unit_file_state']
                    if now != wanted:
                        raise LayoutError(15, 'The unit file state is %r, not the recorded %r.' % (now, wanted))
                steps.append('unit:OK')
            if txn.get('adopt'):
                _restore_adoption(backup, txn, command)
                steps.append('legacy:OK')
            if restored:
                steps.append('labels:' + selinux_relabel(restored))
            remove_config_snapshot(txn)
            txn = txn_update(backup, phase='ROLLBACK_DONE', rollback_steps=steps)
        except (LayoutError, OSError, ValueError, KeyError, sqlite3.Error) as error:
            if isinstance(error, LayoutError) and txn_load(backup)['state'] == 'COMMITTED':
                raise  # refused after the stop: service restored, nothing overwritten
            steps.append('FAILED:' + type(error).__name__)
            message = str(error) if isinstance(error, LayoutError) else type(error).__name__ + ': ' + str(error)[:200]
            try:
                txn_update(backup, phase='ROLLBACK_INCOMPLETE', rollback_steps=steps, rollback_error=message)
            except (LayoutError, OSError, ValueError):
                pass
            try:
                txn_audit(txn, 'ROLLBACK_INCOMPLETE', backup, reason=message[:300], **_rollback_audit_fields(txn))
            except LayoutError:
                pass
            status = 'ROLLBACK_BLOCKED_BY_PROCESSES' if isinstance(error, LayoutError) and error.code == 17 \
                else 'ROLLBACK_INCOMPLETE'
            return {'status': status, 'steps': steps, 'reason': message, 'backup': str(backup),
                    'journal_kept': os.path.lexists(journal_path(data_dir))}
    # 7. audit, terminal state, journal closed -- all before the old version starts (V1001S-03, R-20).
    try:
        # V3C-06: the completion record is replay-safe: its event id is stored
        # durably BEFORE the first write, and a rerun (crash between the record
        # and the terminal state) only checks that the event is there.
        event = txn.get('rollback_event_id')
        if not event:
            event = secrets.token_hex(8)
            txn = txn_update(backup, rollback_event_id=event)
        if not _audit_has_event(data_dir, txn['kind'], event):
            txn_audit(txn, 'ROLLED_BACK', backup, restored=(txn['old'] or {}).get('version') or 'none',
                      **_rollback_audit_fields(txn), event=event)
        kill_point('rollback_after_audit')
    except LayoutError as error:
        return {'status': 'ROLLED_BACK_AUDIT_PENDING', 'steps': steps, 'backup': str(backup),
                'reason': 'Data and files are restored but the audit record failed: ' + str(error) +
                          '. Fix the audit log and rerun the same command to finish.', 'journal_kept': True}
    needs_start = bool(uses_systemd and txn['had_unit'] and txn.get('service_active'))
    if txn.get('adopt'):
        needs_start = any(unit.get('active') for unit in txn['adopt'].get('units', []))
    if txn.get('secure_restore'):
        # V3D-01: closed until an operator approves (start-guard refuses meanwhile).
        write_private_atomic(Path(data_dir) / QUARANTINE_NAME, json.dumps({
            'backup': str(backup), 'txn': txn['txn_id'], 'since': now_iso(),
            'approve': 'INSTALL.sh --production --approve-rollback --backup ' + str(backup)}) + '\n', 0o644)
        needs_start = False
    # V1001T-06: "start + health check of the previous version" is a durable
    # to-do of its own, separate from the terminal state that forbids a
    # second restore; it survives a crash after the journal is closed.
    txn = txn_update(backup, state='ROLLED_BACK', phase='ROLLED_BACK', rolled_back=now_iso(),
                     pending_start=needs_start, quarantine_pending=bool(txn.get('secure_restore')))
    kill_point('rollback_before_journal_remove')
    _remove_journal(txn)
    kill_point('rollback_after_journal_remove')
    result = {'status': 'ROLLED_BACK_QUARANTINED' if txn.get('quarantine_pending') else 'ROLLED_BACK',
              'steps': steps, 'backup': str(backup), 'restored_version': (txn['old'] or {}).get('version')}
    if txn.get('quarantine_pending'):
        result['next'] = ('Data restored to the pre-upgrade copy WITH the current revocations, cleanups and issued '
                          'numbers; every login was ended. The service stays closed until an operator approves: '
                          'sudo bash <package>/INSTALL.sh --production --approve-rollback --backup %s --reviewer ... '
                          '--review-reference ... --confirm-current-access-and-cleanup' % backup)
    if needs_start:
        result = _finish_pending_start(backup, txn, command, health_seconds, result)
    return result


def _finish_pending_start(backup, txn, command, health_seconds, result):
    """8. start the previous version (an event after the rollback, never
    rewriting the terminal state); the to-do is cleared only on success."""
    if txn.get('adopt'):
        return _finish_legacy_start(backup, txn, command, health_seconds, result)
    service = txn.get('service') or SERVICE_NAME
    current, conf = _current_and_conf(txn)
    if current != txn.get('prev_current') or not conf or conf['VERSION'] != (txn['old'] or {}).get('version'):
        # The previous version is no longer what is installed: the to-do is
        # stale (V1001V-01); retire it durably instead of blocking forever.
        retire_todo(backup, {'pending_start': False}, 'installation changed')
        result['superseded'] = True
        return result
    problem = _start_previous(txn, service, command, health_seconds)
    if problem:
        txn_update(backup, post_rollback_start=problem)
        result.update(status='ROLLED_BACK_START_FAILED', reason=problem)
        try:
            txn_audit(txn, 'ROLLED_BACK_START_FAILED', backup, reason=problem[:300])
        except LayoutError:
            pass
        return result
    txn_update(backup, pending_start=False, post_rollback_start=None)
    result.setdefault('steps', []).append('start_previous:OK')
    return result


# ------------------------------------------------------------------ U73 data ownership (V4C-03)
# Handing the v1.000.0 data to the service account and back never acts on a
# path: every level is opened from a trusted directory descriptor with
# O_NOFOLLOW, the object is identified by fstat (type, device, inode, links)
# and changed with fchown/fchmod on that descriptor. Hand-over goes children
# first, so a directory becomes the service account's only after everything
# below it is done (until then the service account cannot add, rename or
# replace entries in it); the way back goes parents first, so the service
# account loses write access to a directory before its entries are touched.

def _open_dir_path(path):
    """Descriptor of the absolute directory PATH, opened level by level from /
    with O_NOFOLLOW (no symlink anywhere on the way)."""
    parts = PurePosixPath(path).parts
    if not parts or parts[0] != '/' or '..' in parts:
        raise LayoutError(12, 'Not a clean absolute path: %s' % path)
    flags = os.O_RDONLY | os.O_DIRECTORY | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in parts[1:]:
            child = os.open(part, flags, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
    except BaseException:
        os.close(descriptor)
        raise
    return descriptor


def _open_child(parent_fd, name, kind):
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | os.O_NONBLOCK | getattr(os, 'O_NOCTTY', 0)
    if kind == 'dir':
        flags |= os.O_DIRECTORY
    return os.open(name, flags, dir_fd=parent_fd)


def _same_object(info, record, kind):
    if kind == 'dir' and not stat.S_ISDIR(info.st_mode):
        return False
    if kind == 'file' and not (stat.S_ISREG(info.st_mode) and info.st_nlink == 1):
        return False
    return 'ino' not in record or (info.st_dev, info.st_ino) == (record['dev'], record['ino'])


def _plan_tree(plan):
    records = {item['path']: item for item in plan['entries']}
    roots = [path for path, item in records.items()
             if item['kind'] == 'dir' and str(PurePosixPath(path).parent) not in records]
    children = {}
    for path in records:
        parent = str(PurePosixPath(path).parent)
        if parent in records and parent != path:
            children.setdefault(parent, []).append(path)
    return records, sorted(roots), children


def ownership_apply(plan, svc_uid, svc_gid):
    """Hand the planned entries to the service account (children first). Any
    entry that is not the very object recorded in the plan (replaced, now a
    link, hard-linked) aborts: the caller's transaction then restores."""
    records, roots, children = _plan_tree(plan)
    for item in plan['traverse']:
        descriptor = _open_dir_path(item['path'])
        try:
            if not _same_object(os.fstat(descriptor), item, 'dir'):
                raise LayoutError(12, 'Directory %s changed since the takeover plan; refused.' % item['path'])
            os.fchmod(descriptor, item['mode'] | 0o001)
        finally:
            os.close(descriptor)

    def hand_over(descriptor, path):
        item = records[path]
        if not _same_object(os.fstat(descriptor), item, item['kind']):
            raise LayoutError(12, 'Data entry %s changed since the takeover plan; refused.' % path)
        for child in sorted(children.get(path, [])):
            record = records[child]
            try:
                child_fd = _open_child(descriptor, PurePosixPath(child).name, record['kind'])
            except OSError as error:
                raise LayoutError(12, 'Data entry %s cannot be opened safely (%s); refused.'
                                  % (child, error.strerror)) from None
            try:
                hand_over(child_fd, child)
            finally:
                os.close(child_fd)
        os.fchown(descriptor, svc_uid, svc_gid)
        os.fchmod(descriptor, item['mode'] & ~0o022)  # never group/other-writable for the service

    for root in roots:
        descriptor = _open_dir_path(root)
        try:
            hand_over(descriptor, root)
        finally:
            os.close(descriptor)


def ownership_restore(plan):
    """Give the planned entries their recorded owner/group/mode back (parents
    first) and the ancestors their traverse bits. Objects are reached only
    through descriptors of already restored parents; a directory that is no
    longer the recorded object is not entered, a link or a hard-linked file is
    never touched. Files the service legitimately recreated under the same
    name (the SQLite database restored by the rollback, its -wal/-shm) are
    restored by name inside their verified, root-owned again directory.
    Returns notes about every entry that was skipped or not the same object."""
    records, roots, children = _plan_tree(plan)
    notes = []

    def give_back(descriptor, path):
        item = records[path]
        info = os.fstat(descriptor)
        if not _same_object(info, item, item['kind']):
            if item['kind'] == 'dir' or not (stat.S_ISREG(info.st_mode) and info.st_nlink == 1):
                notes.append('%s: not the recorded object; left unchanged' % path)
                return
            notes.append('%s: recreated since the takeover; owner restored by name' % path)
        os.fchown(descriptor, item['uid'], item['gid'])
        os.fchmod(descriptor, item['mode'])
        for child in sorted(children.get(path, [])):
            record = records[child]
            try:
                child_fd = _open_child(descriptor, PurePosixPath(child).name, record['kind'])
            except FileNotFoundError:
                continue
            except OSError as error:
                notes.append('%s: %s; left unchanged' % (child, error.strerror))
                continue
            try:
                give_back(child_fd, child)
            finally:
                os.close(child_fd)

    for root in roots:
        try:
            descriptor = _open_dir_path(root)
        except OSError as error:
            notes.append('%s: %s; left unchanged' % (root, error.strerror))
            continue
        try:
            give_back(descriptor, root)
        finally:
            os.close(descriptor)
    for item in plan['traverse']:
        try:
            descriptor = _open_dir_path(item['path'])
        except OSError as error:
            notes.append('%s: %s; traverse bit not restored' % (item['path'], error.strerror))
            continue
        try:
            if _same_object(os.fstat(descriptor), item, 'dir'):
                os.fchmod(descriptor, item['mode'])
            else:
                notes.append('%s: not the recorded directory; left unchanged' % item['path'])
        finally:
            os.close(descriptor)
    return notes


def _restore_adoption(backup, txn, command):
    """U73 rollback of a v1.000.0 takeover: owner/group/mode of the data
    entries and the parents' traverse bits come back from the recorded plan,
    and the legacy unit(s) get their enabled state back (started later as the
    pending start, after the journal is closed)."""
    path = Path(backup) / 'adopt-ownership.json'
    if txn.get('adopt_ownership_sha256'):
        text = read_trusted_text(path, 'adopt-ownership.json')
        if hashlib.sha256(text.encode()).hexdigest() != txn['adopt_ownership_sha256']:
            raise LayoutError(13, 'The recorded data ownership differs from its checksum; refused.')
        plan = json.loads(text)
        notes = ownership_restore(plan)
        if notes:
            txn_update(backup, adopt_restore_notes=notes[-50:])
    for unit in txn['adopt'].get('units', []):
        if unit.get('enabled'):
            rc, _ = systemctl_run(['enable', unit['name']], command)
            if rc != 0:
                raise LayoutError(15, 'Re-enabling the v1.000.0 unit %s failed.' % unit['name'])
    rc, _ = systemctl_run(['daemon-reload'], command)
    if rc != 0:
        raise LayoutError(15, 'systemctl daemon-reload failed while restoring the v1.000.0 unit.')


def legacy_health_ok(value):
    """v1.000.0 answers /api/health without release_version (never guessed
    as a version): only status ok + production mode are accepted."""
    return isinstance(value, dict) and value.get('status') == 'ok' and value.get('mode') == 'production' \
        and 'release_version' not in value


def _finish_legacy_start(backup, txn, command, health_seconds, result):
    adopt = txn['adopt']
    app = Path(txn['app_dir'])
    if os.path.lexists(app / 'current') or os.path.lexists(txn['conf_path']) \
            or not os.path.isfile(Path(adopt['prefix']) / 'INSTALLATION.json'):
        retire_todo(backup, {'pending_start': False}, 'installation changed')
        result['superseded'] = True
        return result
    problem = None
    for unit in adopt.get('units', []):
        if unit.get('active'):
            rc, _ = systemctl_run(['start', unit['name']], command)
            if rc != 0:
                problem = 'systemctl start %s returned %d' % (unit['name'], rc)
                break
    if problem is None:
        deadline = time.monotonic() + health_seconds
        seen = None
        while True:
            seen = health_snapshot(adopt['bind'], adopt['port'], adopt.get('host') or adopt['bind'])
            if legacy_health_ok(seen):
                break
            if time.monotonic() >= deadline:
                problem = 'the v1.000.0 service did not answer its health check (saw %r)' % (seen,)
                break
            time.sleep(1)
    if problem:
        txn_update(backup, post_rollback_start=problem)
        result.update(status='ROLLED_BACK_START_FAILED', reason=problem)
        try:
            txn_audit(txn, 'ROLLED_BACK_START_FAILED', backup, reason=problem[:300])
        except LayoutError:
            pass
        return result
    txn_update(backup, pending_start=False, post_rollback_start=None)
    result.setdefault('steps', []).append('start_v1000:OK')
    return result


def _start_previous(txn, service, command, health_seconds):
    rc, _ = systemctl_run(['start', service], command)
    kill_point('rollback_after_start')
    ok, seen = False, None
    if rc == 0:
        conf = parse_conf(read_trusted_text(txn['conf_path'], 'install.conf'))
        if txn.get('config_sha256') and txn.get('config_path') and \
                config_sha256(read_service_config(txn['config_path'])) != txn['config_sha256']:
            seen = {'release_version': 'config.json changed again'}
        else:
            ok, seen = wait_health(conf['BIND'], conf['API_PORT'], public_host(conf['CONFIG_FILE']),
                                   txn['old']['version'], health_seconds, txn['old'].get('build'))
    if ok:
        return None
    try:
        stop_service_verified(service, command)
        stopped = 'it was stopped again'
    except LayoutError as error:
        stopped = 'IT IS STILL RUNNING: ' + str(error)
    return ('The previous version was restored but did not pass its health check (saw %s); %s. '
            'Start and check it manually.' % ((seen or {}).get('release_version'), stopped))


TODO_FLAGS = ('retire_pending', 'audit_pending', 'quarantine_pending', 'approval_pending', 'pending_start',
              'abort_restart_pending')


def find_todos(data_dir):
    """Every durable to-do in DATA_DIR (V1001V-01/02): [(flag, backup, txn)],
    retire_pending first (it may supersede the others), then older first."""
    found = []
    for candidate in sorted(Path(data_dir).glob('*_backup_*')):
        if not BACKUP_NAME_RE.fullmatch(candidate.name) or not (candidate / 'txn.json').is_file():
            continue
        try:
            txn = txn_load(candidate)
        except (LayoutError, OSError, ValueError):
            continue
        for flag in TODO_FLAGS:
            if txn.get(flag):
                found.append((flag, candidate, txn))
    order = {flag: index for index, flag in enumerate(TODO_FLAGS)}
    return sorted(found, key=lambda item: (order[item[0]], item[2].get('created', '')))


def process_todos(data_dir, *, lock_fd, command=None, health_seconds=60):
    """Finish every to-do (journal-less state). Returns None when there was
    nothing, else the result of the last processed to-do or the first failure."""
    result = None
    for _ in range(20):  # each round re-reads: retiring may clear later to-dos
        todos = find_todos(data_dir)
        if not todos:
            return result
        flag, backup, txn = todos[0]
        acquire_lock(txn['app_dir'], lock_fd)
        txn = txn_load(backup)  # V3C-02: decide on the state read under the lock
        if not txn.get(flag):
            continue  # finished by someone else meanwhile
        if flag == 'retire_pending':
            finish_retire(backup)
            result = {'status': 'COMMIT_FINALIZED', 'backup': str(backup), 'todo': flag}
        elif flag in ('quarantine_pending', 'approval_pending'):
            return {'status': 'ROLLBACK_QUARANTINED', 'backup': str(backup), 'todo': flag,
                    'reason': 'A rollback with --accept-data-loss waits for operator approval; nothing is installed '
                              'or patched before: INSTALL.sh --production --approve-rollback --backup ' + str(backup)}
        elif flag == 'audit_pending':
            try:
                flush_audit_pending(backup)
                result = {'status': 'TODO_AUDIT_WRITTEN', 'backup': str(backup), 'todo': flag}
            except LayoutError as error:
                result = {'status': 'TODO_AUDIT_PENDING', 'backup': str(backup), 'todo': flag,
                          'reason': 'A retired to-do still owes its audit record: %s. Fix the audit log and '
                                    'rerun.' % error}
        elif flag == 'pending_start':
            result = rollback(backup, lock_fd=lock_fd, command=command, health_seconds=health_seconds)
            result['todo'] = flag
        else:
            problem = _restart_current(backup, txn, command, health_seconds)
            result = {'status': 'SERVICE_RESTART_FAILED' if problem else 'SERVICE_RESTARTED',
                      'backup': str(backup), 'reason': problem, 'todo': flag}
        if ROLLBACK_EXIT.get(result['status'], 21) != 0:
            return result
    return result


def recover_open_transaction(data_dir, *, lock_fd, command=None, health_seconds=60):
    """Shared recovery for patch.sh, ROLLBACK_NOW.sh and INSTALL.sh --recover.
    Open journal: COMMITTED -> finish (journal, snapshot, retire, owed
    restart); ROLLED_BACK -> finish; otherwise resume/perform the rollback.
    Then every journal-less to-do (retire_pending, pending_start,
    abort_restart_pending) is processed (V1001V-01/02)."""
    found = open_journal(data_dir)
    result = None
    if found is not None:
        _, txn = found
        if txn['state'] == 'COMMITTED':
            acquire_lock(txn['app_dir'], lock_fd)
            _remove_journal(txn)
            remove_config_snapshot(txn)
            result = {'status': 'COMMIT_FINALIZED', 'backup': txn['backup']}
        else:
            result = rollback(txn['backup'], lock_fd=lock_fd, command=command, health_seconds=health_seconds,
                              trigger={'mode': 'recovery', 'stage': txn.get('phase'),
                                       'reason': 'interrupted run found by a later run'})
        if ROLLBACK_EXIT.get(result['status'], 21) != 0:
            return result
    later = process_todos(data_dir, lock_fd=lock_fd, command=command, health_seconds=health_seconds)
    return later or result


def verify_state(conf_path, release):
    """Full 'already applied' check (V1001R-17): config == install.conf,
    INSTALLATION.json, current, release + runtime files, and the installed
    unit equals the unit rendered from this release."""
    conf = parse_conf(read_trusted_text(conf_path, 'install.conf'))
    reconcile(conf)
    marker = json.loads(read_trusted_text(PurePosixPath(conf['APP_DIR']) / 'INSTALLATION.json', 'INSTALLATION.json'))
    if (marker.get('version'), marker.get('build'), marker.get('release')) != (conf['VERSION'], conf['BUILD'], conf['RELEASE']):
        raise LayoutError(13, 'INSTALLATION.json does not match install.conf.')
    current = os.readlink(PurePosixPath(conf['APP_DIR']) / 'current')
    if current != 'releases/' + conf['RELEASE'] or PurePosixPath(release).name != conf['RELEASE']:
        raise LayoutError(13, 'current does not point at the recorded release.')
    verify_installed(release, conf['RUNTIME_DIR'], read_manifest(release))
    return conf


ROLLBACK_EXIT = {'ROLLED_BACK': 0, 'COMMIT_FINALIZED': 0, 'SERVICE_RESTARTED': 0, 'TODO_AUDIT_WRITTEN': 0,
                 'ROLLED_BACK_AUDIT_PENDING': 22, 'TODO_AUDIT_PENDING': 22,
                 'ROLLED_BACK_START_FAILED': 24, 'ROLLBACK_BLOCKED_BY_PROCESSES': 25, 'SERVICE_RESTART_FAILED': 26,
                 'ROLLED_BACK_QUARANTINED': 27, 'ROLLBACK_QUARANTINED': 27}


def approve_rollback(backup, *, lock_fd=None, reviewer, reference, confirmed, high_water=()):
    """V3D-01: operator attestation for a quarantined rollback (same meaning
    as approve-offline). Opens the database copy; never starts the service.

    V4C-06: resumable. The steps are persisted in this order and a rerun of
    --approve-rollback after an interruption anywhere finishes the SAME
    approval (bound to this transaction by its approval id) instead of being
    refused: (1) approval record (rollback-approval.json + txn), quarantine_pending
    cleared, approval_pending set; (2) the database: RESTORE_BLOCKED names the
    approval id, restore_ready=1 is committed, then RESTORE_BLOCKED becomes the
    approval marker (secure_rollback.py approve --approval-id; an opened
    database is accepted on resume only with that proof); (3) the audit
    record (replay-safe by the approval id); (4) the global
    ROLLBACK_QUARANTINED marker (start-guard) and the approval marker are
    removed, approval_pending cleared."""
    located = txn_load(backup)
    owned = acquire_lock(located['app_dir'], lock_fd)
    try:
        txn = txn_load(backup)
        resumed = bool(txn.get('approval_pending'))
        if txn['state'] != 'ROLLED_BACK' or not (txn.get('quarantine_pending') or resumed):
            raise LayoutError(12, 'This backup has no rollback waiting for approval.')
        if open_journal(txn['data_dir']) is not None:
            raise LayoutError(12, 'A transaction is open; finish it first.')
        if resumed:
            record = txn['rollback_approval']  # the stored approval is finished, never a new one
        else:
            if not (confirmed and reviewer.strip() and reference.strip()):
                raise LayoutError(13, 'Approval needs --reviewer, --review-reference and '
                                  '--confirm-current-access-and-cleanup.')
            record = {'approval_id': secrets.token_hex(16), 'txn': txn['txn_id'],
                      'reviewer': reviewer.strip()[:120], 'reference': reference.strip()[:200],
                      'high_water': [str(mark) for mark in high_water][:50],
                      'operator': operator_identity(), 'at': now_iso(), 'authority_verified_by_software': False}
            write_private_atomic(Path(backup) / 'rollback-approval.json',
                                 json.dumps(record, ensure_ascii=False) + '\n', 0o600)
            txn = txn_update(backup, rollback_approval=record, quarantine_pending=False, approval_pending=True)
            kill_point('approve_after_record')
        if record.get('txn') != txn['txn_id'] or not re.fullmatch('[0-9a-f]{32}', record.get('approval_id', '')):
            raise LayoutError(13, 'The stored approval does not belong to this transaction; refused.')
        if not txn.get('approval_db_opened'):
            release = Path(txn['app_dir']) / txn['prev_current']
            args = ['approve', '--database', txn['database'], '--reviewer', record['reviewer'], '--reference',
                    record['reference'], '--confirmed', '--approval-id', record['approval_id']]
            for mark in record.get('high_water', []):
                args += ['--high-water', mark]
            out = json.loads(_svc_tool_run(Path(backup), txn, release, args, 'rollback-approve').strip().splitlines()[-1])
            txn = txn_update(backup, approval_db_opened=True, approval_counters_raised=out.get('counters_raised', []))
            kill_point('approve_after_database')
        # The audit record precedes the opening of the service: the global
        # marker (start-guard) goes only after it is on disk.
        if not _audit_has_event(txn['data_dir'], txn['kind'], record['approval_id']):
            txn_audit(txn, 'ROLLBACK_APPROVED', backup, reviewer=record['reviewer'], reference=record['reference'],
                      event=record['approval_id'])
        kill_point('approve_after_audit')
        quarantine = Path(txn['data_dir']) / QUARANTINE_NAME
        if os.path.lexists(quarantine):
            os.unlink(quarantine)
            fsync_dir(txn['data_dir'])
        kill_point('approve_after_quarantine_removed')
        marker = Path(txn['database']).parent / ('.rollback-approved-' + record['approval_id'])
        if os.path.lexists(marker):
            os.unlink(marker)
            fsync_dir(marker.parent)
        txn = txn_update(backup, approval_pending=False, approval_done=now_iso())
        return {'status': 'ROLLBACK_APPROVED', 'backup': str(backup), 'service_started': False,
                'resumed_interrupted_approval': resumed,
                'next': 'sudo systemctl start ' + (txn.get('service') or SERVICE_NAME)}
    finally:
        if owned is not None:
            os.close(owned)


# ---------------------------------------------------------------- CLI (patch.sh, ROLLBACK_NOW.sh, ExecStartPre)
def _conf(path):
    return parse_conf(read_trusted_text(path, 'install.conf'))


def _cli(argv=None):
    parser = argparse.ArgumentParser(prog='layout.py')
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('compare'); p.add_argument('left'); p.add_argument('right')
    p = sub.add_parser('read-conf'); p.add_argument('path')
    p = sub.add_parser('set-conf'); p.add_argument('path'); p.add_argument('pairs', nargs='+')
    p = sub.add_parser('render-unit'); p.add_argument('template'); p.add_argument('conf'); p.add_argument('output')
    p.add_argument('--check', action='store_true', help='compare with output instead of writing it')
    p = sub.add_parser('port-free'); p.add_argument('bind'); p.add_argument('port')
    p = sub.add_parser('quiesce-check'); p.add_argument('conf')
    p = sub.add_parser('unit-owner-check'); p.add_argument('unit'); p.add_argument('conf')
    p = sub.add_parser('free-port'); p.add_argument('bind')
    p = sub.add_parser('health'); p.add_argument('conf'); p.add_argument('expected')
    p.add_argument('--build'); p.add_argument('--port', type=int); p.add_argument('--seconds', type=int, default=60)
    p = sub.add_parser('verify-installed'); p.add_argument('release'); p.add_argument('runtime')
    p = sub.add_parser('verify-state'); p.add_argument('conf'); p.add_argument('release')
    p = sub.add_parser('reconcile'); p.add_argument('conf'); p.add_argument('--config')
    p = sub.add_parser('audit'); p.add_argument('data_dir'); p.add_argument('kind'); p.add_argument('pairs', nargs='*')
    p = sub.add_parser('txn-begin'); p.add_argument('conf'); p.add_argument('record')
    p.add_argument('--unit'); p.add_argument('--layout-source', required=True); p.add_argument('--tag')
    p = sub.add_parser('txn-update'); p.add_argument('backup'); p.add_argument('pairs', nargs='+')
    p = sub.add_parser('txn-child'); p.add_argument('backup'); p.add_argument('pid', type=int)
    p = sub.add_parser('txn-child-done'); p.add_argument('backup'); p.add_argument('pid', type=int)
    p = sub.add_parser('service-state')
    p = sub.add_parser('run-token'); p.add_argument('action', choices=['create', 'remove'])
    p.add_argument('--backup'); p.add_argument('--pid', type=int); p.add_argument('--check-pgid', type=int)
    p.add_argument('--config')
    p = sub.add_parser('open-gate'); p.add_argument('backup'); p.add_argument('name'); p.add_argument('owner', type=int)
    p = sub.add_parser('check-port-auth'); p.add_argument('data_dir'); p.add_argument('--token', default=RUN_TOKEN)
    p = sub.add_parser('txn-db-backup'); p.add_argument('backup')
    p = sub.add_parser('txn-precommit'); p.add_argument('backup')
    p = sub.add_parser('txn-commit'); p.add_argument('backup')
    p = sub.add_parser('txn-field'); p.add_argument('backup'); p.add_argument('field')
    p = sub.add_parser('journal'); p.add_argument('data_dir')
    p = sub.add_parser('recover'); p.add_argument('data_dir'); p.add_argument('--lock-fd', type=int, required=True)
    p.add_argument('--seconds', type=int, default=60)
    p = sub.add_parser('rollback'); p.add_argument('--backup'); p.add_argument('--data')
    p.add_argument('--lock-fd', type=int); p.add_argument('--accept-data-loss', action='store_true')
    p.add_argument('--seconds', type=int, default=60)
    p.add_argument('--trigger', choices=('manual', 'automatic', 'recovery'), default='manual')
    p.add_argument('--stage', default=''); p.add_argument('--reason', default='')
    p = sub.add_parser('set-marker'); p.add_argument('path'); p.add_argument('version'); p.add_argument('build')
    p.add_argument('release')
    p = sub.add_parser('kill-point'); p.add_argument('name')
    p = sub.add_parser('check-dir'); p.add_argument('path'); p.add_argument('label')
    p = sub.add_parser('start-guard'); p.add_argument('data_dir'); p.add_argument('--token')
    p = sub.add_parser('fsync-tree'); p.add_argument('path')
    p = sub.add_parser('fsync-dir'); p.add_argument('path')
    sub.add_parser('stop-service')
    args = parser.parse_args(argv)
    try:
        if args.command == 'compare':
            print(compare_versions(args.left, args.right))
        elif args.command == 'read-conf':
            print(json.dumps(_conf(args.path), ensure_ascii=False))
        elif args.command == 'set-conf':
            values = _conf(args.path)
            for pair in args.pairs:
                key, _, value = pair.partition('=')
                if key not in CONF_KEYS:
                    raise LayoutError(13, 'Unknown install.conf key.')
                values[key] = value
            info = os.stat(args.path)
            parse_conf(format_conf(values))
            write_private_atomic(args.path, format_conf(values), stat.S_IMODE(info.st_mode))
        elif args.command == 'render-unit':
            text = render_unit(Path(args.template).read_text(encoding='utf-8'), _conf(args.conf))
            if args.check:
                if not os.path.isfile(args.output) or Path(args.output).read_text(encoding='utf-8') != text:
                    raise LayoutError(13, 'The installed unit differs from the unit of this release.')
            else:
                write_private_atomic(args.output, text, 0o644)
        elif args.command == 'port-free':
            return 0 if check_port_free(args.bind, args.port) else 1
        elif args.command == 'quiesce-check':
            values = _conf(args.conf)
            ensure_quiesced(values['BIND'], values['API_PORT'], values['DATABASE_PATH'])
        elif args.command == 'unit-owner-check':
            values = _conf(args.conf)
            check_unit_belongs(args.unit, values['APP_DIR'], values['DATA_DIR'], values['RUNTIME_DIR'])
        elif args.command == 'free-port':
            print(free_port(args.bind))
        elif args.command == 'health':
            values = _conf(args.conf)
            ok, seen = wait_health(values['BIND'], args.port or values['API_PORT'], public_host(values['CONFIG_FILE']),
                                   args.expected, args.seconds, args.build)
            print(json.dumps({'expected': args.expected, 'expected_build': args.build, 'ok': ok,
                              'release_version': (seen or {}).get('release_version'),
                              'build': (seen or {}).get('build'), 'mode': (seen or {}).get('mode')}))
            return 0 if ok else 1
        elif args.command == 'verify-installed':
            verify_installed(args.release, args.runtime, read_manifest(args.release))
            print('OK')
        elif args.command == 'verify-state':
            verify_state(args.conf, args.release)
            print('OK')
        elif args.command == 'reconcile':
            result = reconcile(_conf(args.conf), args.config)
            print(json.dumps({'database': result['database'], 'config_sha256': result['config_sha256']}))
        elif args.command == 'audit':
            audit(args.data_dir, args.kind, **dict(pair.partition('=')[::2] for pair in args.pairs))
        elif args.command == 'txn-begin':
            conf = _conf(args.conf)
            record = json.loads(args.record)
            import pwd
            entry = pwd.getpwnam(conf['SVC_USER'])
            checked = reconcile(conf, owners={entry.pw_uid})
            state = service_state_for_txn(unit_exists=bool(args.unit) and os.path.exists(args.unit))
            record.update({'app_dir': conf['APP_DIR'], 'runtime_dir': conf['RUNTIME_DIR'],
                           'database': conf['DATABASE_PATH'], 'attachments': conf['ATTACHMENTS_DIR'],
                           'service': SERVICE_NAME, 'svc_uid': entry.pw_uid, 'svc_gid': entry.pw_gid,
                           'service_enabled': state['enabled'], 'service_active': state['active'],
                           'service_unit_state': state['unit_file_state']})
            print(txn_begin(conf['DATA_DIR'], 'patch', record, conf_path=args.conf, unit_path=args.unit,
                            marker_path=str(PurePosixPath(conf['APP_DIR']) / 'INSTALLATION.json'),
                            layout_source=args.layout_source, tag=args.tag, config_value=checked['value'],
                            svc_gid=entry.pw_gid, config_path=conf['CONFIG_FILE']))
        elif args.command == 'txn-update':
            fields = {}
            for pair in args.pairs:
                key, _, value = pair.partition('=')
                if key not in ('phase',):
                    raise LayoutError(13, 'Only the phase can be updated from the command line.')
                fields[key] = value
            txn_update(args.backup, **fields)
        elif args.command == 'txn-child':
            register_child(args.backup, args.pid)
        elif args.command == 'txn-child-done':
            return 0 if finish_child(args.backup, args.pid) else 15
        elif args.command == 'service-state':
            print(json.dumps(service_state()))
        elif args.command == 'run-token':
            if args.action == 'create':
                txn = txn_load(args.backup)
                if args.check_pgid is not None and args.check_pgid not in [int(c['pgid']) for c in txn.get('children') or []]:
                    raise LayoutError(15, 'The check-port process group is not registered in the transaction.')
                if args.config is not None and args.config != txn.get('config_snapshot'):
                    raise LayoutError(15, 'The check port must use the transaction configuration snapshot.')
                create_run_token(txn['txn_id'], args.pid, args.check_pgid, args.config)
            else:
                remove_run_token()
        elif args.command == 'open-gate':
            gate = Path(args.backup) / ('gate-' + args.name + '-' + str(args.owner))
            descriptor = os.open(gate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            os.close(descriptor)
        elif args.command == 'check-port-auth':
            ok, reason = check_port_authorized(args.data_dir, args.token)
            print(reason, file=sys.stderr)
            return 0 if ok else 1
        elif args.command == 'txn-field':
            value = txn_load(args.backup).get(args.field)
            if value is None or not CONF_VALUE_RE.fullmatch(str(value)):
                raise LayoutError(13, 'Transaction field is missing or not shell-safe.')
            print(value)
        elif args.command == 'txn-db-backup':
            txn = txn_load(args.backup)
            target = Path(args.backup) / 'database.sqlite'
            digest, identity = sqlite_backup_with_identity(txn['database'], target, txn.get('svc_uid'))
            txn_update(args.backup, db_backup=str(target), db_backup_sha256=digest, db_identity=identity,
                       phase='DB_BACKED_UP')
            print(digest)
        elif args.command == 'txn-precommit':
            precommit(args.backup)
        elif args.command == 'txn-commit':
            txn_commit(args.backup)
        elif args.command == 'journal':
            found = open_journal(args.data_dir)
            print(json.dumps(None if found is None else {'backup': found[1]['backup'], 'phase': found[1]['phase'],
                                                         'state': found[1]['state'],
                                                         'package': found[1].get('package')}))
        elif args.command == 'recover':
            result = recover_open_transaction(args.data_dir, lock_fd=args.lock_fd, health_seconds=args.seconds)
            print(json.dumps(result or {'status': 'NO_OPEN_TRANSACTION'}, ensure_ascii=False))
            return 0 if result is None else ROLLBACK_EXIT.get(result['status'], 21)
        elif args.command == 'rollback':
            backup = args.backup
            if backup is None:
                found = open_journal(args.data) if args.data else None
                if found is None:
                    print(json.dumps({'status': 'NO_OPEN_TRANSACTION'}))
                    return 0
                backup = found[1]['backup']
            result = rollback(backup, lock_fd=args.lock_fd, accept_data_loss=args.accept_data_loss,
                              health_seconds=args.seconds,
                              trigger={'mode': args.trigger, 'stage': args.stage[:80], 'reason': args.reason[:300]})
            print(json.dumps(result, ensure_ascii=False))
            return ROLLBACK_EXIT.get(result['status'], 21)
        elif args.command == 'set-marker':
            write_private_atomic(args.path, json.dumps({
                'mode': 'production', 'version': args.version, 'build': args.build,
                'status': 'INSTALLED_PRODUCTION_CANDIDATE', 'release': args.release}, indent=2) + '\n', 0o644)
        elif args.command == 'kill-point':
            if test_mode() and os.environ.get('PROJECTAPP_TEST_KILL_AT') == args.name:
                os.kill(os.getppid(), 9)
        elif args.command == 'check-dir':
            check_trusted_dir(args.path, args.label)
        elif args.command == 'start-guard':
            ok, reason = start_guard(args.data_dir)
            if not ok:
                print('ProjectApp start refused: ' + reason, file=sys.stderr)
            return 0 if ok else 1
        elif args.command == 'fsync-tree':
            fsync_tree(args.path)
        elif args.command == 'fsync-dir':
            fsync_dir(args.path)
        elif args.command == 'stop-service':
            stop_service_verified()
        return 0
    except LayoutError as error:
        print(json.dumps({'status': 'REJECTED', 'reason': str(error), 'exit_code': error.code}), file=sys.stderr)
        return error.code
    except (OSError, ValueError, KeyError, sqlite3.Error) as error:
        import traceback
        frame = traceback.extract_tb(error.__traceback__)[-1]
        print(json.dumps({'status': 'FAIL', 'command': args.command, 'error_type': type(error).__name__,
                          'detail': str(error)[:300], 'at': '%s:%d' % (frame.name, frame.lineno)}), file=sys.stderr)
        return 13


if __name__ == '__main__':
    sys.exit(_cli())
