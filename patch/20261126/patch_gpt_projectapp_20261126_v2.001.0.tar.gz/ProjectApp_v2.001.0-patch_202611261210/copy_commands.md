# ProjectApp_v2.001.0-patch_202611261210 傳送與執行指令

以下路徑為例子，依實際主機調整。修補期間服務會停止（維護時段），請先通知使用者並暫停對外連線。

## 1. 傳到主機並核對

```sh
scp ProjectApp_v2.001.0-patch_202611261210.tar.gz ProjectApp_v2.001.0-patch_202611261210.tar.gz.sha256 <帳號>@<主機>:/tmp/
ssh <帳號>@<主機>
cd /tmp
sha256sum -c ProjectApp_v2.001.0-patch_202611261210.tar.gz.sha256
```

只有交付關卡產出的正式包才有 `.sha256` 檔；檔名結尾是 `.DRAFT` 的是未過關卡的草稿，`patch.sh` 會拒絕安裝。

## 2. 解開（root 專用目錄，不要放在安裝目錄底下）

解開的目錄保持只有 root 能進入（`patch.sh` 會拒絕其他帳號能改動的來源）；
所以以下指令**一律用絕對路徑**，不需要也不要 `cd` 進去（一般帳號 `cd` 會被拒）：

```sh
sudo mkdir -m 700 /root/projectapp-patches
sudo tar -xzf /tmp/ProjectApp_v2.001.0-patch_202611261210.tar.gz -C /root/projectapp-patches
sudo ls /root/projectapp-patches/ProjectApp_v2.001.0-patch_202611261210
```

若檔案曾經過 Windows 轉存導致 `patch.sh` 變成 CRLF，先執行：
`sudo sed -i 's/\r$//' /root/projectapp-patches/ProjectApp_v2.001.0-patch_202611261210/patch.sh`（其他檔案不要改，否則 SHA256SUMS 核對會失敗）。
目錄名稱必須維持 `ProjectApp_v2.001.0-patch_202611261210`；`patch.sh` 會先把整包複製到 root 專用的暫存目錄、核對後只用那份副本。

## 3. 執行修補

```sh
sudo bash /root/projectapp-patches/ProjectApp_v2.001.0-patch_202611261210/patch.sh
# 資料目錄不是預設 /opt/projectapp/data 且無法從 systemd 單元讀到時：
sudo PROJECTAPP_DATA=/srv/projectapp/data bash /root/projectapp-patches/ProjectApp_v2.001.0-patch_202611261210/patch.sh
```

基底版本：2.000.30 → 新版本：2.001.0。安裝中的版本比基底舊會被拒絕。

### 例外：強制套用在較舊的基底上（PROJECTAPP_ALLOW_OLD_BASE）

沿用 WEBIT3 的「要硬套設環境變數」規則（使用者規則，保留）。**只在下列條件都成立時才可使用**：

1. 「目前安裝版本 → 2.001.0」這個跨基底組合，已在測試機用同一份修補包實際套用、驗證並留有紀錄（測試紀錄或變更單編號）。
2. 有寫下為什麼不能先補齊中間的修補或改用完整包。
3. 願意讓這次操作連同上述紀錄編號寫進稽核紀錄。

環境變數本身**不是**相容性批准，只是讓已驗證過的組合可以執行。值必須**完全等於本包的 BASE_VER**，而且要附上驗證紀錄：

```sh
sudo PROJECTAPP_ALLOW_OLD_BASE=2.000.30 PROJECTAPP_ALLOW_OLD_BASE_REASON='<測試機驗證紀錄或變更單編號>' \
    bash /root/projectapp-patches/ProjectApp_v2.001.0-patch_202611261210/patch.sh
```

- 值不等於 `2.000.30`（例如寫 `1` 或其他版本），或沒有附 `PROJECTAPP_ALLOW_OLD_BASE_REASON`（至少 8 個字），都會直接拒絕，什麼都不改。
- 執行時會印出醒目警告，並在 `patch_audit.log` 寫一筆 `result=OLD_BASE_OVERRIDE`（含目前版本、基底版本與 `evidence=` 驗證紀錄）；稽核寫不進去就不套用。
- 只略過「基底版本」這一關；新 release 仍須完全符合它的檔案清單與雜湊，不符就自動回復。基底到目前版本之間的變更不在本包內，請確定這是你要的。

## 4. 驗證

```sh
systemctl status projectapp --no-pager
curl -s -H 'Host: <正式主機名稱>' http://127.0.0.1:<API_PORT>/api/health   # release_version 應為 2.001.0、mode 為 production
sudo tail -n 5 /opt/projectapp/data/patch_audit.log
```

失敗時請看 `ROLLBACK.md`。
