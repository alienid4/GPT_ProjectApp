#!/bin/bash
# ProjectApp patch installer (v1.001 release rules).
#
# Run from the extracted patch directory as root:  sudo bash patch.sh
#
#  0. bootstrap (this file, from a source tree that only root can modify):
#     copy the package into a fresh root-private mktemp directory, verify the
#     copy against SHA256SUMS, then run the verified copy
#  1. verify SHA256SUMS, PACKAGE_MANIFEST.txt, DELETE.txt / file paths
#  2. read install.conf (root-owned, trusted directories only), take the
#     install/patch lock, re-read install.conf, finish/recover an earlier run
#  3. version gates: refuse downgrade / same version / older than BASE_VER
#     (PROJECTAPP_ALLOW_OLD_BASE=<exact BASE_VER> overrides, loudly audited)
#  4. verify the running release, build the new release next to it, verify
#  5. maintenance window (transaction journal open, real service stopped):
#     snapshot the verified config -> stop (must really stop) -> SQLite copy
#     -> switch current, install.conf, INSTALLATION.json -> unit +
#     daemon-reload -> schema upgrade as SVC_USER -> verify the new release on
#     a loopback check port -> success audit -> commit (journal closed)
#  6. only then start the real service and check /api/health version, build
#     and mode. A failed start after the commit is stopped and rolled back
#     only if the database and attachments did not change since the commit.
# Any failure inside the window runs the shared rollback (layout.py rollback).
# ROLLED_BACK is reported only if every step and the old version's health
# check succeeded. While the journal is open the unit refuses to start.
#
# Environment:
#   PROJECTAPP_DATA              data dir holding install.conf (default: from the
#                                installed unit, else /opt/projectapp/data)
#   PROJECTAPP_ALLOW_OLD_BASE=<BASE_VER>  allow an installed version older than
#                                BASE_VER; must equal this patch's BASE_VER exactly
#   PROJECTAPP_HEALTH_SECONDS    health wait (default 90)
# Test-only (honoured only for a non-root run with PROJECTAPP_ALLOW_NONROOT=1):
#   PROJECTAPP_SYSTEMCTL, PROJECTAPP_JOURNALCTL, PROJECTAPP_SYSTEMD_DIR,
#   PROJECTAPP_STAGE_PARENT, PROJECTAPP_RUN_TOKEN, PROJECTAPP_ALLOW_DRAFT,
#   PROJECTAPP_TEST_KILL_AT.
# Exit codes: 0 ok, 10-14 refused (nothing changed), 20 rolled back,
#   21 rollback incomplete (journal kept), 22 restored but audit pending,
#   23 started after commit, failed, stopped, automatic rollback refused,
#   24 rolled back (final, audited) but the previous version did not start,
#   25 rollback blocked: an orphaned process group cannot be proven to be ours (manual).
{
set -Eeuo pipefail
umask 077
export LC_ALL=C
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
unset PYTHONHOME PYTHONPATH PYTHONSTARTUP LD_PRELOAD LD_AUDIT LD_LIBRARY_PATH

log() { printf '[patch %s] %s\n' "$(date '+%F %T')" "$*" >&2; }

TEST_MODE=0
if [[ $EUID -ne 0 ]]; then
    if [[ "${PROJECTAPP_ALLOW_NONROOT:-0}" != 1 ]]; then
        echo 'patch.sh must run as root (sudo bash patch.sh).' >&2; exit 10
    fi
    TEST_MODE=1
fi
test_env() { [[ $TEST_MODE -eq 1 ]] && printf '%s' "${!1:-}"; return 0; }

PKG_NAME_RE='^ProjectApp_v[0-9]{1,3}\.[0-9]{3}\.[0-9]{1,3}-patch_[0-9]{12}$'
STAGE_NAME_RE='^projectapp-patch\.[A-Za-z0-9]{10}$'
SAFE='^[A-Za-z0-9._/:+@-]*$'
VER_RE='^[0-9]{1,3}\.[0-9]{3}\.[0-9]{1,3}$'     # every part 0..999, same as layout.py
REL_LINK_RE='^releases/[0-9]{1,3}\.[0-9]{3}\.[0-9]{1,3}-[0-9a-f]{12}$'
SVC_RE='^[a-z_][a-z0-9_-]{0,31}$'
ACCESS_PY='import os, sys
bad = []
for root in sys.argv[1:]:
    for d, dirs, files in os.walk(root, onerror=lambda e: bad.append(str(e.filename))):
        if not os.access(d, os.R_OK | os.X_OK): bad.append(d)
        for f in files:
            p = os.path.join(d, f)
            if not os.path.islink(p) and not os.access(p, os.R_OK): bad.append(p)
print(" ".join(bad[:5]) or "ACCESS_OK"); sys.exit(1 if bad else 0)'
GATE_SH='i=0; while [ ! -e "$1" ]; do i=$((i+1)); [ "$i" -gt 600 ] && exit 99; sleep 0.1; done; shift; exec "$@"'
STAGE_PARENT=$(test_env PROJECTAPP_STAGE_PARENT); STAGE_PARENT=${STAGE_PARENT:-/var/tmp}

mode_ok() { # $1 octal mode, $2 1 = sticky g/o-writable ancestor allowed
    local m=$((8#$1))
    (( (m & 8#022) == 0 )) && return 0
    [[ $2 == 1 ]] && (( m & 8#1000 )) && return 0
    return 1
}
ancestors_trusted() { # every ancestor: not a link, owned by root/EUID, not g/o-writable unless sticky
    local a=$1 u m
    while [[ "$a" != / ]]; do
        a=$(dirname -- "$a")
        [[ ! -L "$a" ]] || return 1
        read -r u m < <(stat -c '%u %a' -- "$a")
        [[ "$u" == 0 || "$u" == "$EUID" ]] && mode_ok "$m" 1 || return 1
    done
}
members_match() { # $1 dir: exact member list and hashes of SHA256SUMS
    local actual expected
    actual=$(cd -- "$1" && find . -type f ! -path ./SHA256SUMS -printf '%P\n' | sort)
    expected=$(sed -n 's/^[0-9a-f]\{64\}  //p' "$1/SHA256SUMS" | sort)
    [[ "$actual" == "$expected" ]] && (cd -- "$1" && sha256sum --strict --check --status SHA256SUMS)
}

# ------------------------------------------------------------ 0. bootstrap: verified private copy
if [[ -z "${PROJECTAPP_PATCH_STAGE:-}" ]]; then
    src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
    name=$(basename -- "$src")
    [[ "$name" =~ $PKG_NAME_RE ]] || { log "REFUSED: the package directory must be named ProjectApp_v<version>-patch_<yyyymmddHHMM>."; exit 11; }
    # V1001R-01: nobody but root may be able to change the tree this code was
    # read from; otherwise the copy below could already be a different script.
    if find "$src" \( ! -user "$EUID" -o \( ! -type l -perm /022 \) \) -print -quit | grep -q . \
            || ! ancestors_trusted "$src/x"; then
        log 'REFUSED: extract the patch as root into a root-only directory (e.g. sudo mkdir -m 700 /root/projectapp-patches); files or parent directories here can be changed by another account.'
        exit 11
    fi
    if find "$src" -mindepth 1 ! -type f ! -type d -print -quit | grep -q .; then
        log 'REFUSED: symbolic links or special files are not allowed in a patch package.'; exit 11
    fi
    stage=$(mktemp -d "$STAGE_PARENT/projectapp-patch.XXXXXXXXXX")
    chmod 700 -- "$stage"
    token=$(od -An -N16 -tx1 /dev/urandom | tr -d ' \n')
    printf '%s' "$token" > "$stage/.run-token"
    mkdir -m 700 -- "$stage/$name"
    if ! cp -R --preserve=mode -- "$src/." "$stage/$name/" \
            || find "$stage/$name" -mindepth 1 ! -type f ! -type d -print -quit | grep -q . \
            || ! members_match "$stage/$name"; then
        rm -rf -- "$stage"; log 'REFUSED: the private copy of the package does not match SHA256SUMS.'; exit 11
    fi
    export PROJECTAPP_PATCH_STAGE="$stage" PROJECTAPP_PATCH_NAME="$name" PROJECTAPP_PATCH_TOKEN="$token"
    exec /bin/bash "$stage/$name/patch.sh" "$@"
fi

# ------------------------------------------------------------ staged run: prove the stage is ours (V1001R-02)
STAGE_DIR=$PROJECTAPP_PATCH_STAGE
PKG_NAME=${PROJECTAPP_PATCH_NAME:-}
RUN_TOKEN_VALUE=${PROJECTAPP_PATCH_TOKEN:-}
unset PROJECTAPP_PATCH_STAGE PROJECTAPP_PATCH_NAME PROJECTAPP_PATCH_TOKEN
PKG=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
stage_ok=0
if [[ "$PKG_NAME" =~ $PKG_NAME_RE && "$RUN_TOKEN_VALUE" =~ ^[0-9a-f]{32}$ && "$(dirname -- "$STAGE_DIR")" == "$STAGE_PARENT" \
        && "$(basename -- "$STAGE_DIR")" =~ $STAGE_NAME_RE && ! -L "$STAGE_DIR" && -d "$STAGE_DIR" \
        && "$PKG" == "$STAGE_DIR/$PKG_NAME" && ! -L "$STAGE_DIR/.run-token" && -f "$STAGE_DIR/.run-token" ]]; then
    if [[ "$(stat -c '%u %a' -- "$STAGE_DIR")" == "$EUID 700" && "$(stat -c '%u %h' -- "$STAGE_DIR/.run-token")" == "$EUID 1" \
            && "$(cat -- "$STAGE_DIR/.run-token")" == "$RUN_TOKEN_VALUE" ]]; then
        stage_ok=1
    fi
fi
if [[ $stage_ok -ne 1 ]]; then
    log 'REFUSED: patch.sh must be started from the extracted package directory (staging proof missing).'
    exit 11
fi
cleanup_stage() { rm -rf -- "$STAGE_DIR"; return 0; }   # only the verified mktemp directory of this run
trap cleanup_stage EXIT

SERVICE=projectapp
read -r -a SYSTEMCTL <<< "$(test_env PROJECTAPP_SYSTEMCTL)"; [[ ${#SYSTEMCTL[@]} -gt 0 ]] || SYSTEMCTL=(systemctl)
read -r -a JOURNALCTL <<< "$(test_env PROJECTAPP_JOURNALCTL)"; [[ ${#JOURNALCTL[@]} -gt 0 ]] || JOURNALCTL=(journalctl)
SYSTEMD_DIR=$(test_env PROJECTAPP_SYSTEMD_DIR); SYSTEMD_DIR=${SYSTEMD_DIR:-/etc/systemd/system}
UNIT="$SYSTEMD_DIR/$SERVICE.service"
HEALTH_SECONDS=${PROJECTAPP_HEALTH_SECONDS:-90}
[[ "$HEALTH_SECONDS" =~ ^[0-9]{1,4}$ ]] || HEALTH_SECONDS=90
TS=$(date +%Y%m%d%H%M%S)_$$   # pid suffix: a quick rerun never reuses a backup dir
CHANGED=0          # 1 once the transaction journal is open
COMMITTED=0
AUDIT_READY=0
TXN_ID=""
B=""
STAGE=verify_package
CHECK_PID=""

audit() { # result key=value...
    [[ $AUDIT_READY -eq 1 ]] || return 0
    local op
    op=$(id -un)
    if [[ "${SUDO_USER:-}" =~ ^[a-z_][a-z0-9_.-]{0,31}$ ]]; then op="$SUDO_USER(sudo)"; fi
    "$PY" -I -B "$TOOL" audit "$DATA" patch "package=$PKG_NAME" "operator=$op" "txn=${TXN_ID:--}" \
        "from=${CUR_VER:-?}" "to=${NEW_VER:-?}" "result=$1" "${@:2}"
}
refuse() {
    local code=$1; shift
    if [[ $CHANGED -eq 1 ]]; then log "ERROR: $*"; on_failure "$code"; fi
    log "REFUSED: $*"
    audit REFUSED "reason=$*" || log 'WARNING: the audit record could not be written.'
    exit "$code"
}
kill_point() { # test-only crash injection
    if [[ $TEST_MODE -eq 1 && "${PROJECTAPP_TEST_KILL_AT:-}" == "$1" ]]; then kill -9 $$; fi
    return 0
}

# ------------------------------------------------------------ trust helpers
trusted_dir() { # path label: real dir, owned by root, not g/o-writable; ancestors trusted
    local p=$1 label=$2 u m
    [[ "$p" == /* && ! -L "$p" && -d "$p" ]] || refuse 12 "$label must be a real directory: $p"
    read -r u m < <(stat -c '%u %a' -- "$p")
    [[ "$u" == "$EUID" ]] && mode_ok "$m" 0 || refuse 12 "$label must be owned by root and not group/other-writable: $p"
    ancestors_trusted "$p" || refuse 12 "$label: an ancestor of $p is a link, foreign-owned or writable by others."
}
trusted_file() { # path label
    local u m h
    [[ ! -L "$1" && -f "$1" ]] || refuse 12 "$2 must be a regular file: $1"
    read -r u m h < <(stat -c '%u %a %h' -- "$1")
    [[ "$u" == "$EUID" && "$h" == 1 ]] && mode_ok "$m" 0 || refuse 12 "$2 must be root-owned, without hard links, not group/other-writable."
}
trusted_tree() { # every entry root-owned, nothing g/o-writable (links excepted)
    if find "$1" \( ! -user "$EUID" -o \( ! -type l -perm /022 \) \) -print -quit | grep -q .; then
        refuse 12 "$2 contains files not owned by root or writable by others: $1"
    fi
}

# ------------------------------------------------------------ 1. package integrity (private copy)
cd -- "$PKG"
[[ -f SHA256SUMS && -f PACKAGE_MANIFEST.txt && -f DELETE.txt ]] || refuse 11 'Package files are missing.'
members_match "$PKG" || refuse 11 'Package checksum verification failed (members or hashes differ from SHA256SUMS).'
log "Package checksums OK: $PKG_NAME"

manifest_value() {
    local value
    value=$(tr -d '\r' < PACKAGE_MANIFEST.txt | sed -n "s/^$1=//p" | head -n 1)
    [[ -n "$value" && "$value" =~ $SAFE ]] || refuse 11 "PACKAGE_MANIFEST.txt: $1 missing or invalid."
    printf '%s' "$value"
}
[[ "$(manifest_value FORMAT)" == projectapp-patch-1 ]] || refuse 11 'Unsupported patch format.'
[[ "$(manifest_value PACKAGE)" == "$PKG_NAME" ]] || refuse 11 'PACKAGE_MANIFEST.txt PACKAGE differs from the package directory name.'
case "$(manifest_value RELEASE_STATE)" in
    GATED) ;;
    DRAFT) [[ "$(test_env PROJECTAPP_ALLOW_DRAFT)" == 1 ]] \
               || refuse 11 'This is a DRAFT package (built without the delivery gate); it must not be installed.' ;;
    *) refuse 11 'PACKAGE_MANIFEST.txt RELEASE_STATE is invalid.' ;;
esac
BASE_VER=$(manifest_value BASE_VER)
NEW_VER=$(manifest_value NEW_VER)
NEW_BUILD=$(manifest_value NEW_BUILD)
NEW_RELEASE=$(manifest_value NEW_RELEASE)
[[ "$BASE_VER" =~ $VER_RE && "$NEW_VER" =~ $VER_RE ]] || refuse 11 'Versions must use X.YYY.Z (each part 0..999).'
[[ "$NEW_BUILD" =~ ^[0-9a-f]{64}$ && "$NEW_RELEASE" == "$NEW_VER-${NEW_BUILD:0:12}" ]] || refuse 11 'Release identity is invalid.'

# ------------------------------------------------------------ 2. path validation (before any change)
valid_rel() {
    local p=$1
    [[ -n "$p" ]] || return 1
    [[ "$p" != /* ]] || return 1                      # absolute
    [[ "$p" != *\\* ]] || return 1                    # backslash
    [[ "$p" != *[$'\x01'-$'\x1f'$'\x7f']* ]] || return 1   # control characters
    local part; local -a parts
    IFS=/ read -r -a parts <<< "$p"
    for part in "${parts[@]}"; do
        [[ -n "$part" && "$part" != . && "$part" != .. ]] || return 1
    done
    [[ "$p" != */ && "$p" != *//* ]] || return 1
    [[ "$p" != runtime/* && "$p" != runtime ]] || return 1   # runtime changes need a full package
    return 0
}
DELETES=()
while IFS= read -r line || [[ -n "$line" ]]; do
    line=${line%$'\r'}
    [[ -z "${line//[[:space:]]/}" || "$line" == \#* ]] && continue
    if ! valid_rel "$line" || [[ "$line" == MANIFEST.json || "$line" == SHA256SUMS ]]; then
        refuse 11 "DELETE.txt contains an unsafe path (whole patch aborted, nothing changed): $line"
    fi
    DELETES+=("$line")
done < DELETE.txt
FILES=()
if [[ -d app ]]; then
    while IFS= read -r -d '' f; do
        valid_rel "$f" || refuse 11 "Unsafe file name in app/: $f"
        FILES+=("$f")
    done < <(cd app && find . -type f -printf '%P\0' | sort -z)
fi
[[ ${#FILES[@]} -gt 0 ]] || refuse 11 'Patch contains no files under app/.'
for f in "${FILES[@]}"; do
    for d in "${DELETES[@]}"; do [[ "$f" != "$d" ]] || refuse 11 "Path is both deleted and replaced: $f"; done
done
log "Paths validated: ${#FILES[@]} file(s) to copy, ${#DELETES[@]} to delete."

# ------------------------------------------------------------ 3. install.conf + trust boundary
STAGE=read_install_conf
DATA=${PROJECTAPP_DATA:-}
if [[ -z "$DATA" && -f "$UNIT" && ! -L "$UNIT" ]]; then
    DATA=$(sed -n 's/^Environment=PROJECTAPP_DATA=//p' "$UNIT" | head -n 1)
fi
DATA=${DATA:-/opt/projectapp/data}
[[ "$DATA" == /* && "$DATA" =~ $SAFE && "$DATA" != */ && "$DATA" != *//* && "/$DATA/" != */../* && "/$DATA/" != */./* ]] \
    || refuse 12 'Data directory path is invalid.'
CONF="$DATA/install.conf"
if [[ ! -e "$CONF" ]]; then
    if [[ -f /opt/it-workboard/INSTALLATION.json ]]; then
        refuse 12 "No v1.001 install.conf at $CONF, but a v1.000.0 installation exists in /opt/it-workboard. Patches never upgrade v1.000.0 in place; follow README_PRODUCTION.md section '從 v1.000.0 移轉' (backup + export-ledger, then a fresh v1.001.0 install and restore)."
    fi
    refuse 12 "install.conf not found at $CONF (set PROJECTAPP_DATA)."
fi
trusted_dir "$DATA" 'DATA_DIR'
trusted_file "$CONF" 'install.conf'
declare -A C=()
read_conf() {
    C=()
    local key value line
    while IFS= read -r line || [[ -n "$line" ]]; do
        [[ -z "$line" || "$line" == \#* ]] && continue
        [[ "$line" =~ ^([A-Z_]+)=(.*)$ ]] || refuse 12 'install.conf has an invalid line.'
        key=${BASH_REMATCH[1]}; value=${BASH_REMATCH[2]}
        [[ "$value" =~ $SAFE ]] || refuse 12 "install.conf value for $key is invalid."
        C[$key]=$value
    done < "$CONF"
    for key in VERSION BUILD RELEASE API_PORT BIND SVC_USER APP_DIR DATA_DIR RUNTIME_DIR DATABASE_PATH DB_DIR CONFIG_FILE BACKUP_DIR; do
        [[ -n "${C[$key]:-}" ]] || refuse 12 "install.conf is missing $key."
    done
    [[ "${C[DATA_DIR]}" == "$DATA" ]] || refuse 12 'install.conf DATA_DIR does not match its location.'
    [[ "${C[SVC_USER]}" =~ $SVC_RE && "${C[SVC_USER]}" != root ]] || refuse 12 'SVC_USER is invalid or root.'
    [[ "${C[VERSION]}" =~ $VER_RE && "${C[BUILD]}" =~ ^[0-9a-f]{64}$ ]] || refuse 12 'install.conf VERSION/BUILD invalid.'
    for key in APP_DIR RUNTIME_DIR; do
        [[ "${C[$key]}" == /* && "${C[$key]}" != */ && "/${C[$key]}/" != */../* && "/${C[$key]}/" != */./* ]] \
            || refuse 12 "install.conf $key is not a normalized absolute path."
    done
}
read_conf
APP=${C[APP_DIR]}; RUNTIME=${C[RUNTIME_DIR]}; SVC=${C[SVC_USER]}
trusted_dir "$APP" 'APP_DIR'
trusted_dir "$APP/releases" 'APP_DIR/releases'
trusted_dir "$RUNTIME" 'RUNTIME_DIR'
trusted_tree "$RUNTIME" 'RUNTIME_DIR'
PY="$RUNTIME/bin/python3"
[[ -x "$PY" && -L "$APP/current" ]] || refuse 12 'Installed runtime or current release link is missing.'
CUR_REL=$(readlink -- "$APP/current")
[[ "$CUR_REL" =~ $REL_LINK_RE && -d "$APP/$CUR_REL" && ! -L "$APP/$CUR_REL" ]] \
    || refuse 12 'The current link does not point at a managed release directory.'
trusted_tree "$APP/$CUR_REL" 'Current release'

# Trusted layout.py: from this (verified) package when it ships one, else the
# installed release's copy after checking it against that release's SHA256SUMS.
if [[ -f "$PKG/app/tools/layout.py" ]]; then
    TOOL_SRC="$PKG/app/tools/layout.py"
else
    (cd -- "$APP/$CUR_REL" && grep -E '^[0-9a-f]{64}  tools/layout\.py$' SHA256SUMS | sha256sum --strict --check --status) \
        || refuse 11 'Installed tools/layout.py does not match its release SHA256SUMS.'
    TOOL_SRC="$APP/$CUR_REL/tools/layout.py"
fi
TOOL="$STAGE_DIR/layout.py"
cp -- "$TOOL_SRC" "$TOOL"
AUDIT_READY=1

as_service() {
    # fd 9 (the lock) is closed for the child only; never put a redirection on
    # the function call itself: the ERR trap would then run without the lock fd.
    if [[ $EUID -eq 0 ]]; then
        runuser -u "$SVC" -- "$@" 9>&-
    else
        [[ "$(id -un)" == "$SVC" ]] || refuse 12 'Non-root test mode requires SVC_USER to be the current user.'
        "$@" 9>&-
    fi
}
service_command() { # prints nothing; sets SVC_CMD array for a command run as SVC_USER
    if [[ $EUID -eq 0 ]]; then SVC_CMD=(runuser -u "$SVC" -- "$@"); else SVC_CMD=("$@"); fi
}
spawn_registered() { # name command... : own session + process group, recorded in the transaction (V1001R-05)
    local name=$1; shift
    local gate="$B/gate-$name-$$"
    setsid /bin/sh -c "$GATE_SH" gate "$gate" "$@" 9>&- &
    SPAWNED=$!
    if ! "$PY" -I -B "$TOOL" txn-child "$B" "$SPAWNED"; then
        kill -KILL -- "-$SPAWNED" 2>/dev/null || true
        return 1
    fi
}
open_gate() { # name : let the recorded child start
    "$PY" -I -B "$TOOL" open-gate "$B" "$1" $$
}

# ------------------------------------------------------------ 4. lock (shared with the installer), re-read state
STAGE=lock
LOCKDIR=$(dirname -- "$APP")
trusted_dir "$LOCKDIR" 'Lock directory'
LOCK="$LOCKDIR/.$(basename -- "$APP").install.lock"
[[ ! -L "$LOCK" ]] || refuse 12 'The install lock must not be a symbolic link.'
exec 9>>"$LOCK"
read -r lock_uid lock_links lock_type < <(stat -L -c '%u %h %F' /proc/self/fd/9)
[[ "$lock_uid" == "$EUID" && "$lock_links" == 1 && "$lock_type" == regular* ]] || refuse 12 'Unsafe install lock file.'
flock -n 9 || refuse 12 'Another install/patch/rollback operation holds the lock.'
before="$APP|$RUNTIME|$SVC"
read_conf
[[ "${C[APP_DIR]}|${C[RUNTIME_DIR]}|${C[SVC_USER]}" == "$before" ]] || refuse 12 'install.conf changed while waiting for the lock; rerun.'

health_check() { # version build [--port N]
    "$PY" -I -B "$TOOL" health "$CONF" "$1" --build "$2" --seconds "$HEALTH_SECONDS" "${@:3}"
}
print_diagnostics() {
    log '--- journalctl (last 50 lines) ---'
    "${JOURNALCTL[@]}" -u "$SERVICE" -n 50 --no-pager >&2 9>&- || log 'journalctl unavailable'
    log '--- direct import check as SVC_USER ---'
    local src="${NEW_REL:-$APP/current}/app/src"
    if as_service env -i PATH=/usr/bin:/bin LANG=C.UTF-8 "$PY" -I -B -c \
            'import sys; sys.path.insert(0, sys.argv[1]); import workboard.app; print("IMPORT_OK")' "$src" >&2; then :
    else log 'IMPORT_FAILED (see traceback above)'; fi
    log "--- SELinux mode: $(getenforce 2>/dev/null || echo 'getenforce unavailable') ---"
}
stop_check_server() {
    [[ -n "$CHECK_PID" ]] || return 0
    kill -TERM -- "-$CHECK_PID" 2>/dev/null || true
    local i
    for i in $(seq 60); do kill -0 -- "-$CHECK_PID" 2>/dev/null || break; sleep 0.5; done
    kill -KILL -- "-$CHECK_PID" 2>/dev/null || true
    wait "$CHECK_PID" 2>/dev/null || true
    CHECK_PID=""
}
rollback_and_exit() { # $1 exit code of the failure
    local rc out
    set +e
    # Direct child of this shell (no command substitution): the result line is
    # kept in the backup directory and read back afterwards.
    "$PY" -I -B "$TOOL" rollback --backup "$B" --lock-fd 9 --seconds "$HEALTH_SECONDS" \
        --trigger automatic --stage "$STAGE" --reason "patch.sh failed with exit ${1:-?} at stage $STAGE" \
        > "$B/rollback-result.json"
    rc=$?
    out=$(cat -- "$B/rollback-result.json" 2>/dev/null)
    printf '%s\n' "$out" >&2
    case $rc in
        0)  if [[ "$out" == *start_previous:OK* ]]; then
                log "ROLLED BACK: $CUR_VER is in place again; the service was restarted and passed its health check. Backup kept at $B"
            else
                log "ROLLED BACK: files, configuration and database of $CUR_VER are in place again. The service was NOT running before this patch, so it was not started and not health-checked. Backup kept at $B"
            fi
            exit 20 ;;
        24) log "ROLLED BACK (final and audited), but $CUR_VER did not start or failed its health check."
            log 'Check the journal output above and start/fix the service manually; nothing more is rolled back.'
            exit 24 ;;
        25) log 'ROLLBACK BLOCKED: a process group of this run lost its leader and its members cannot be proven to be ours.'
            log "Nothing was signalled or overwritten. Check: ps -o pid,pgid,lstart,cmd -e; then rerun this patch.sh or $B/ROLLBACK_NOW.sh"
            exit 25 ;;
        27) log 'ROLLED BACK and QUARANTINED: waits for operator approval (see ROLLBACK.md).'
            exit 27 ;;
        22) log 'Data and files are restored, but the rollback audit record could not be written (the rollback is not finished).'
            log "Fix $DATA/patch_audit.log, then run: sudo bash $B/ROLLBACK_NOW.sh   (it only finishes the record)."
            log 'Rerunning this patch.sh instead first finishes the record and then applies the patch AGAIN.'
            exit 22 ;;
        *)  log 'AUTOMATIC ROLLBACK DID NOT COMPLETE. The journal stays open and the service refuses to start.'
            log "After fixing the cause run:  sudo bash $B/ROLLBACK_NOW.sh   (or simply rerun this patch.sh)"
            exit 21 ;;
    esac
}
on_failure() {
    local rc=${1:-1}
    # A failing command inside a subshell re-enters here; let the parent handle it.
    [[ $BASHPID == "$$" ]] || exit "$rc"
    trap - ERR INT TERM
    set +e
    stop_check_server
    if [[ $CHANGED -eq 0 ]]; then
        log "FAILED before any installed file changed (exit $rc); nothing to roll back."
        audit FAILED_NO_CHANGE "exit=$rc" "stage=$STAGE" || log 'WARNING: the audit record could not be written.'
        [[ -n "${STAGING:-}" && -d "$STAGING" ]] && rm -rf -- "$STAGING"
        exit "$rc"
    fi
    print_diagnostics
    if [[ $COMMITTED -eq 1 ]]; then
        log "The committed release failed at stage $STAGE (exit $rc); stopping it."
        if ! "$PY" -I -B "$TOOL" stop-service 9>&-; then
            log 'The new version could not be stopped; nothing else was changed. Stop it manually, then decide.'
            exit 21
        fi
        "$PY" -I -B "$TOOL" rollback --backup "$B" --lock-fd 9 --seconds "$HEALTH_SECONDS" \
            --trigger automatic --stage "$STAGE" --reason "post-commit failure exit $rc" >&2
        rc=$?
        case $rc in
            0)  log "ROLLED BACK after a failed post-commit start (database and attachments were unchanged)."; exit 20 ;;
            21|22|24|25) log "Rollback after the failed post-commit start ended with code $rc (see above)."; exit "$rc" ;;
        esac
        log 'Automatic rollback was refused (see the reason above). The service is stopped.'
        log "Decide manually: sudo bash $B/ROLLBACK_NOW.sh --accept-data-loss  (or fix and start the service)"
        exit 23
    fi
    log "FAILED at stage $STAGE (exit $rc): rolling back to $CUR_VER from $B"
    rollback_and_exit "$rc"
}

# V3D-03: the fixed unit name belongs to exactly one installation.
"$PY" -I -B "$TOOL" unit-owner-check "$UNIT" "$CONF" \
    || refuse 12 "$UNIT does not belong to the installation in $DATA (see above); nothing was stopped or changed."

# ------------------------------------------------------------ 5. finish or recover an earlier run
STAGE=recover
journal=$("$PY" -I -B "$TOOL" journal "$DATA") || refuse 12 "The transaction journal in $DATA is invalid; inspect it manually."
set +e
recovered=$("$PY" -I -B "$TOOL" recover "$DATA" --lock-fd 9 --seconds "$HEALTH_SECONDS")
rc=$?
set -e
[[ "$recovered" == *NO_OPEN_TRANSACTION* ]] || journal=${journal/null/pending-start}
if [[ "$journal" != null ]]; then
    log "An earlier install/patch run did not finish ($journal); it was finished or rolled back first: $recovered"
    case $rc in
        0)  audit RECOVERED_INTERRUPTED || refuse 14 'Audit record could not be written.' ;;
        22) refuse 22 "An earlier run (or a retired to-do) still owes its audit record; nothing else was changed now. Fix $DATA/patch_audit.log, then rerun: the rerun first finishes that record and then CONTINUES with this patch (to finish only the record, run INSTALL.sh --production --recover)." ;;
        24) refuse 24 'The earlier run was rolled back, but the previous version did not start; fix and start it, then rerun.' ;;
        27) refuse 27 'An earlier rollback with --accept-data-loss waits for operator approval (INSTALL.sh --production --approve-rollback, see ROLLBACK.md); nothing is patched before that.' ;;
        25) refuse 25 'A process group of the earlier run cannot be proven to be ours; nothing was signalled. Check it manually (see above), then rerun.' ;;
        *)  refuse 21 'Recovery of the interrupted run did not complete; the journal stays open. Fix the cause and rerun.' ;;
    esac
    read_conf
    CUR_REL=$(readlink -- "$APP/current")
    [[ "$CUR_REL" =~ $REL_LINK_RE ]] || refuse 12 'The current link is invalid after recovery.'
fi

# ------------------------------------------------------------ 6. version gates
STAGE=version_gates
CUR_VER=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([0-9]*\.[0-9]*\.[0-9]*\)".*/\1/p' "$APP/$CUR_REL/app/version.json" 2>/dev/null | head -n 1)
[[ "$CUR_VER" =~ $VER_RE ]] || refuse 12 'Cannot detect the installed version.'
[[ "$CUR_VER" == "${C[VERSION]}" ]] || refuse 12 "install.conf says ${C[VERSION]} but the current release is $CUR_VER; inspect the installation."
vercmp() { # both validated by VER_RE: at most 3 digits per part, no overflow
    local IFS=. i; local -a a=($1) b=($2)
    for i in 0 1 2; do
        if (( 10#${a[i]} > 10#${b[i]} )); then echo 1; return; fi
        if (( 10#${a[i]} < 10#${b[i]} )); then echo -1; return; fi
    done
    echo 0
}
if [[ "$(basename -- "$CUR_REL")" == "$NEW_RELEASE" ]]; then
    # V1001-21 / V1001R-17: "already applied" only after the full state check.
    log "current already points at $NEW_RELEASE; verifying config, marker, files, unit, service and health."
    [[ "${C[VERSION]}" == "$NEW_VER" && "${C[BUILD]}" == "$NEW_BUILD" && "${C[RELEASE]}" == "$NEW_RELEASE" ]] \
        || refuse 13 'current points at the new release but install.conf does not match it; inspect the installation.'
    "$PY" -I -B "$TOOL" verify-state "$CONF" "$APP/$CUR_REL" >/dev/null \
        || refuse 13 "Release $NEW_VER is current but config, INSTALLATION.json, files or runtime do not match."
    "$PY" -I -B "$TOOL" render-unit "$APP/$CUR_REL/tools/projectapp.service.in" "$CONF" "$UNIT" --check \
        || refuse 13 "Release $NEW_VER is current but the installed unit differs from it."
    if ! "${SYSTEMCTL[@]}" is-active --quiet "$SERVICE" 9>&-; then
        # Committed (no journal) but never started: an earlier run stopped right
        # after its commit. Finish it: start the committed release and verify it.
        log "Release $NEW_VER is committed but $SERVICE is not running; starting it now."
        "${SYSTEMCTL[@]}" start "$SERVICE" 9>&- || refuse 13 "Release $NEW_VER is committed but $SERVICE does not start; check it (journalctl -u $SERVICE)."
    fi
    health_check "$NEW_VER" "$NEW_BUILD" >&2 || refuse 13 "Release $NEW_VER is current but /api/health does not report it (version/build/mode)."
    audit ALREADY_APPLIED || refuse 14 'Audit record could not be written.'
    log "Already at $NEW_VER ($NEW_RELEASE); nothing to apply."
    exit 0
fi
case $(vercmp "$NEW_VER" "$CUR_VER") in
    -1|0) refuse 12 "Downgrade/same-version refused: installed $CUR_VER, patch $NEW_VER." ;;
esac
if [[ $(vercmp "$CUR_VER" "$BASE_VER") == -1 ]]; then
    override=${PROJECTAPP_ALLOW_OLD_BASE:-}
    if [[ -z "$override" ]]; then
        refuse 12 "Installed $CUR_VER is older than this patch's base $BASE_VER; apply the earlier patches or a full package first."
    elif [[ "$override" != "$BASE_VER" ]]; then
        [[ "$override" =~ $VER_RE ]] || override='(not a version)'
        refuse 12 "PROJECTAPP_ALLOW_OLD_BASE must equal this patch's BASE_VER ($BASE_VER) exactly; got $override. Nothing changed."
    fi
    # V3D-09 (WEBIT3 rule kept): only for a CUR_VER -> NEW_VER combination that was
    # already verified on the test host; the reference to that evidence is required.
    reason=${PROJECTAPP_ALLOW_OLD_BASE_REASON:-}
    reason=${reason//[^A-Za-z0-9 ._:\/#()-]/_}
    [[ ${#reason} -ge 8 ]] || refuse 12 "PROJECTAPP_ALLOW_OLD_BASE also needs PROJECTAPP_ALLOW_OLD_BASE_REASON: the test-host evidence that $CUR_VER -> $NEW_VER was verified (at least 8 characters, e.g. a change/test record id). Nothing changed."
    log '************************************************************************'
    log "WARNING: OLD-BASE OVERRIDE. Installed $CUR_VER is OLDER than BASE_VER $BASE_VER."
    log 'Files changed between those versions are NOT in this patch; the full file'
    log 'verification below still refuses a release that does not match its manifest.'
    log 'This override is recorded in the audit log.'
    log '************************************************************************'
    audit OLD_BASE_OVERRIDE "installed=$CUR_VER" "base=$BASE_VER" "override=$override" "evidence=${reason:0:200}" \
        || refuse 14 'Audit record for the old-base override could not be written; nothing changed.'
fi
log "Upgrade $CUR_VER -> $NEW_VER (base $BASE_VER)"
"$PY" -I -B "$TOOL" reconcile "$CONF" >/dev/null \
    || refuse 13 'config.json and install.conf disagree or the database is missing (details above); nothing changed.'
audit STARTED || refuse 14 "The audit log $DATA/patch_audit.log cannot be written; nothing changed."

trap 'on_failure $?' ERR
trap 'log "Interrupted by signal"; on_failure 130' INT TERM

# ------------------------------------------------------------ 7. verify running release, build new one
STAGE=verify_current
"$PY" -I -B "$TOOL" verify-installed "$APP/$CUR_REL" "$RUNTIME" >/dev/null \
    || refuse 11 'The installed release does not match its own manifest (modified or wrong base); nothing changed.'
STAGE=build_release
NEW_REL="$APP/releases/$NEW_RELEASE"
STAGING="$NEW_REL.partial-$TS"
if [[ -e "$NEW_REL" || -L "$NEW_REL" ]]; then
    mv -T -- "$NEW_REL" "$NEW_REL.retained-$TS"
    log "Existing $NEW_REL retained as $NEW_REL.retained-$TS"
fi
cp -a -- "$APP/$CUR_REL/." "$STAGING"
parents_safe() { # no symlink among the parent directories of $STAGING/$1
    local acc=$STAGING part i; local -a parts
    IFS=/ read -r -a parts <<< "$1"
    for (( i = 0; i < ${#parts[@]} - 1; i++ )); do
        acc="$acc/${parts[i]}"
        [[ ! -L "$acc" ]] || return 1
        [[ ! -e "$acc" || -d "$acc" ]] || return 1
    done
}
for d in "${DELETES[@]}"; do
    parents_safe "$d" || { log "DELETE.txt path crosses a symbolic link or file: $d"; false; }
    if [[ -e "$STAGING/$d" || -L "$STAGING/$d" ]]; then
        if [[ -d "$STAGING/$d" && ! -L "$STAGING/$d" ]]; then rm -rf -- "$STAGING/$d"; else rm -f -- "$STAGING/$d"; fi
    else
        log "DELETE.txt entry not present (ok): $d"
    fi
done
for f in "${FILES[@]}"; do
    parents_safe "$f" || { log "Patch path crosses a symbolic link or file: $f"; false; }
    [[ ! -d "$STAGING/$f" || -L "$STAGING/$f" ]] || { log "Patch file replaces a directory (needs a full package): $f"; false; }
    mkdir -p -- "$(dirname -- "$STAGING/$f")"
    rm -f -- "$STAGING/$f"
    cp -- "$PKG/app/$f" "$STAGING/$f"
    # Fixed modes: the service account must read every release file, whatever
    # umask the operator used when extracting the patch archive.
    if [[ -x "$PKG/app/$f" || "$f" == *.sh ]]; then chmod 755 -- "$STAGING/$f"; else chmod 644 -- "$STAGING/$f"; fi
    if [[ "$f" == *.sh ]]; then sed -i 's/\r$//' -- "$STAGING/$f"; fi
done
find "$STAGING" -type d ! -perm 755 -exec chmod 755 -- {} +
chmod -R go-w -- "$STAGING"
[[ $EUID -ne 0 ]] || chown -R root:root -- "$STAGING"
grep -q "\"build\": \"$NEW_BUILD\"" "$STAGING/MANIFEST.json" || { log 'New MANIFEST.json build differs from PACKAGE_MANIFEST.txt'; false; }
"$PY" -I -B "$TOOL" verify-installed "$STAGING" "$RUNTIME" >/dev/null \
    || { log 'New release does not match its manifest (wrong base installed?)'; false; }
staged_ver=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([0-9.]*\)".*/\1/p' "$STAGING/app/version.json" | head -n 1)
[[ "$staged_ver" == "$NEW_VER" ]] || { log 'app/version.json in the new release differs from NEW_VER'; false; }
# V1001U-02: the service account itself must be able to read the new
# release and execute the runtime before anything changes.
access=$(as_service env -i PATH=/usr/bin:/bin "$PY" -I -B -c "$ACCESS_PY" "$STAGING" "$RUNTIME") \
    || { log "The service account cannot read: $access"; false; }
"$PY" -I -B "$TOOL" fsync-tree "$STAGING"
mv -T -- "$STAGING" "$NEW_REL"
"$PY" -I -B "$TOOL" fsync-dir "$APP/releases"
STAGING=""
log "New release built, verified and synced: $NEW_REL"

# ------------------------------------------------------------ 8. transaction: backups, config snapshot, journal
STAGE=backup
PREV_RELEASE=$CUR_REL
# Service enabled/active state is queried by txn-begin with the tri-state
# rule (V1001S-12): an unknown answer refuses before any change.
PKG_SHA=$(sha256sum -- "$PKG/PACKAGE_MANIFEST.txt" | cut -c1-64)
record=$(printf '{"package":"%s","package_manifest_sha256":"'"$PKG_SHA"'","systemd":true,"old":{"version":"%s","build":"%s","release":"%s"},"new":{"version":"%s","build":"%s","release":"%s"},"prev_current":"%s"}' \
    "$PKG_NAME" "$CUR_VER" "${C[BUILD]}" "$(basename -- "$CUR_REL")" "$NEW_VER" "$NEW_BUILD" "$NEW_RELEASE" \
    "$PREV_RELEASE")
B=$("$PY" -I -B "$TOOL" txn-begin "$CONF" "$record" --unit "$UNIT" --layout-source "$TOOL" --tag "$TS")
CHANGED=1
TXN_ID=$("$PY" -I -B "$TOOL" txn-field "$B" txn_id)
SNAPSHOT=$("$PY" -I -B "$TOOL" txn-field "$B" config_snapshot)
mkdir -m 700 -- "$B/app"
(cd -- "$APP/$CUR_REL" && for f in "${FILES[@]}" "${DELETES[@]}"; do
    if [[ -e "$f" || -L "$f" ]]; then cp -a --parents -- "$f" "$B/app/"; fi
done)
log "Maintenance window opened (journal + config snapshot); backup directory: $B"
kill_point after_backup

# ------------------------------------------------------------ 9. stop service, check config, back up DB
STAGE=stop_service
"$PY" -I -B "$TOOL" stop-service 9>&-
STAGE=quiesce_check
# V3C-03: a process outside the unit (e.g. a foreground RUN.sh serve) must not
# serve or hold the database while it is copied or the release is switched.
"$PY" -I -B "$TOOL" quiesce-check "$CONF" 9>&-
STAGE=reconcile
"$PY" -I -B "$TOOL" reconcile "$CONF" --config "$SNAPSHOT" >/dev/null
STAGE=database_backup
"$PY" -I -B "$TOOL" txn-db-backup "$B" > "$B/database.sqlite.sha256"
log "SQLite backup: $B/database.sqlite"
kill_point after_db_backup

# ------------------------------------------------------------ 10. switch release, install.conf, marker
STAGE=switch_release
"$PY" -I -B "$TOOL" txn-update "$B" phase=SWITCHING
ln -s -- "releases/$NEW_RELEASE" "$APP/.current-$TS"
mv -T -- "$APP/.current-$TS" "$APP/current"
"$PY" -I -B "$TOOL" fsync-dir "$APP"
"$PY" -I -B "$TOOL" set-conf "$CONF" "VERSION=$NEW_VER" "BUILD=$NEW_BUILD" "RELEASE=$NEW_RELEASE" \
    "UPDATED_TIME=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >/dev/null
"$PY" -I -B "$TOOL" set-marker "$APP/INSTALLATION.json" "$NEW_VER" "$NEW_BUILD" "$NEW_RELEASE"
read_conf
[[ "${C[VERSION]}" == "$NEW_VER" && "${C[BUILD]}" == "$NEW_BUILD" ]] || { log 'install.conf read-back mismatch'; false; }
kill_point after_copy

# ------------------------------------------------------------ 11. port + unit
STAGE=port_check
"$PY" -I -B "$TOOL" port-free "${C[BIND]}" "${C[API_PORT]}" \
    || { log "Port ${C[BIND]}:${C[API_PORT]} is still in use after stopping $SERVICE"; false; }
STAGE=unit
"$PY" -I -B "$TOOL" render-unit "$NEW_REL/tools/projectapp.service.in" "$CONF" "$UNIT"
"${SYSTEMCTL[@]}" daemon-reload 9>&-

# ------------------------------------------------------------ 12. schema migration (own process group, recorded)
STAGE=schema_upgrade
"$PY" -I -B "$TOOL" txn-update "$B" phase=MIGRATING
service_command env -i PATH=/usr/bin:/bin LANG=C.UTF-8 LD_LIBRARY_PATH="$NEW_REL/vendor/lib" \
    "$PY" -I -B "$NEW_REL/tools/upgrade_database.py" --config "$SNAPSHOT"
spawn_registered migration "${SVC_CMD[@]}" >&2
open_gate migration
wait "$SPAWNED"
"$PY" -I -B "$TOOL" txn-child-done "$B" "$SPAWNED"
"$PY" -I -B "$TOOL" reconcile "$CONF" --config "$SNAPSHOT" >/dev/null
kill_point after_migration

# ------------------------------------------------------------ 13. verify on a loopback check port (service still stopped)
STAGE=check_port_verification
"$PY" -I -B "$TOOL" txn-update "$B" phase=VERIFYING
CHECK_PORT=$("$PY" -I -B "$TOOL" free-port "${C[BIND]}")
service_command env -i PATH=/usr/bin:/bin LANG=C.UTF-8 PROJECTAPP_RUNTIME="$RUNTIME" PROJECTAPP_DATA="$DATA" \
    /bin/bash "$NEW_REL/RUN.sh" --production serve --config "$SNAPSHOT" --check-port "$CHECK_PORT"
spawn_registered check-port "${SVC_CMD[@]}" >/dev/null 2>&1
CHECK_PID=$SPAWNED
# V1001T-04: the token names the registered group and the config snapshot.
"$PY" -I -B "$TOOL" run-token create --backup "$B" --pid $$ --check-pgid "$CHECK_PID" --config "$SNAPSHOT"
open_gate check-port
health_check "$NEW_VER" "$NEW_BUILD" --port "$CHECK_PORT" >&2
check_pgid=$CHECK_PID
stop_check_server
"$PY" -I -B "$TOOL" run-token remove
"$PY" -I -B "$TOOL" txn-child-done "$B" "$check_pgid"
log "New release answered on check port $CHECK_PORT with $NEW_VER / build ${NEW_BUILD:0:12} / production."

# ------------------------------------------------------------ 14. commit (audit first, then close the journal)
STAGE=commit
"$PY" -I -B "$TOOL" txn-precommit "$B"
audit SUCCESS "backup=$B"
"$PY" -I -B "$TOOL" txn-commit "$B"
COMMITTED=1
log "Committed $CUR_VER -> $NEW_VER; maintenance window closed."

# ------------------------------------------------------------ 15. start the real service + health
STAGE=start_service
"${SYSTEMCTL[@]}" start "$SERVICE" 9>&-
kill_point after_start
STAGE=health_check
health_check "$NEW_VER" "$NEW_BUILD" >&2
trap - ERR INT TERM
audit SERVICE_HEALTHY "backup=$B" || log 'WARNING: the SERVICE_HEALTHY audit record could not be written (the patch itself is committed).'

log "SUCCESS: $CUR_VER -> $NEW_VER. Previous release kept at $APP/$PREV_RELEASE; backup at $B"
log "Manual rollback later (refused if attachments changed; --accept-data-loss if the database changed):"
log "  sudo bash $B/ROLLBACK_NOW.sh"
exit 0
}
